# Build APK — Smart Live Chat v14

Project ini adalah project Android Studio standar (Gradle + Kotlin). APK tidak bisa
dibangun di sandbox ini (tidak ada Android SDK), jadi build dilakukan di komputer Anda.

## Yang dibutuhkan

- Android Studio (versi terbaru, Hedgehog/Iguana ke atas) — https://developer.android.com/studio
- JDK 17 (sudah termasuk di Android Studio)
- Koneksi internet (Gradle akan mengunduh dependency)

## Langkah build

1. **Buka project**
   Android Studio → *Open* → pilih folder `smart-live-chat/` (bukan folder induknya).

2. **Tunggu Gradle sync**
   Pertama kali bisa 3–10 menit karena mengunduh Gradle 8.7 + dependency Firebase.
   Kalau muncul prompt "Trust project", pilih *Trust*.

3. **Build APK debug (untuk tes)**
   Menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
   Hasil: `app/build/outputs/apk/debug/app-debug.apk`

4. **Build APK release (untuk dibagikan)**
   - **Build → Generate Signed Bundle / APK → APK → Next**
   - Buat keystore baru (isi password & alias), atau pakai yang sudah ada
   - Pilih **release** → **Create**
   - Hasil: `app/build/outputs/apk/release/app-release.apk`

5. **Install ke HP**
   Salin APK ke HP, buka, izinkan "Install unknown apps", lalu install.
   Atau lewat kabel: `adb install -r app-release.apk`

## Setelah install — sekali saja

Agar panggilan masuk selalu muncul layar penuh:

1. **Izin notifikasi** — izinkan saat diminta.
2. **Full-screen intent** (Android 14+):
   Setelan → Aplikasi → Smart Live Chat → *Full-screen notifications* → aktifkan.
   (Aplikasi juga punya tombol untuk membuka setelan ini.)
3. **Baterai** — Setelan → Aplikasi → Smart Live Chat → Baterai → *Unrestricted*
   (jangan "Optimized"), supaya service panggilan tidak dimatikan sistem.
4. **Izin mikrofon & kamera** — izinkan saat panggilan pertama.

## Kalau build gagal

| Gejala | Penyebab & solusi |
|---|---|
| `google-services.json missing` | File harus ada di `app/google-services.json` (sudah disertakan). |
| `Failed to resolve: com.google.firebase...` | Tidak ada internet, atau Gradle sync belum selesai. Coba *File → Sync Project with Gradle Files*. |
| `Unsupported class file major version` | JDK salah. *File → Settings → Build → Gradle → Gradle JDK* → pilih **17**. |
| `SDK location not found` | Buka *File → Project Structure → SDK Location*, arahkan ke Android SDK. |
| Error `namespace` / AGP | Pastikan Android Studio terbaru (AGP 8.5.2 butuh Studio Iguana+). |

## Ganti konfigurasi Firebase

`app/google-services.json` diisi dari konfigurasi yang sudah dipakai aplikasi
(project `my-chat-86ac6`, package `ai.smartools.livechat`). Kalau Anda memakai
project Firebase lain:

1. Firebase Console → Project settings → *Your apps* → Android app
   dengan package `ai.smartools.livechat`.
2. Unduh `google-services.json` baru, timpa file di `app/`.
3. Pastikan `www/app.js` (dan `app/src/main/assets/www/app.js`) berisi
   `firebaseConfig` yang sesuai.

## Catatan

- Kode di sini **belum dikompilasi** — belum diuji di HP. Yang sudah diperiksa:
  sintaks JavaScript valid (`node --check`) dan tampilan layar panggilan dirender
  headless 412×915 sesuai rancangan.
- Untuk panggilan lintas jaringan yang andal, isi TURN server sendiri di
  `ICE_SERVERS` pada `www/app.js` (saat ini memakai relay publik).
