/* ============================================================
   SMART LIVE CHAT — Android app (Firebase Realtime Database)
   ============================================================ */
const firebaseConfig = {
  apiKey: "AIzaSyDhQuQJML3-A__QFHlzXrEt_gpyPCM5eVM",
  authDomain: "my-chat-86ac6.firebaseapp.com",
  databaseURL: "https://my-chat-86ac6-default-rtdb.firebaseio.com",
  projectId: "my-chat-86ac6",
  storageBucket: "my-chat-86ac6.firebasestorage.app",
  messagingSenderId: "84663638961",
  appId: "1:84663638961:android:aced5a60e107b95a283b90"
};
/* Inisialisasi Firebase dibuat tahan-gagal: kalau konfigurasi bermasalah,
   aplikasi TETAP terbuka dan menampilkan pesan yang jelas, bukan layar putih. */
let auth = null, db = null, storage = null;
try {
  firebase.initializeApp(firebaseConfig);
  auth = firebase.auth();
  db = firebase.database();
  storage = firebase.storage();
  auth.setPersistence(firebase.auth.Auth.Persistence.LOCAL).catch(()=>{});
} catch (e) {
  console.error('Firebase init gagal:', e);
  window.__SLC_FIREBASE_ERROR__ = (e && e.message) || 'Konfigurasi Firebase tidak valid';
}

const APK_URL = "https://static.teamily.ai/sites/dccff507-0f92-4261-ac65-764a92ddabbd/documents/smart-live-chat-v3-fixed/smart-live-chat-v3.0-fixed.apk?tk=c2l0ZTpkY2NmZjUwNy0wZjkyLTQyNjEtYWM2NS03NjRhOTJkZGFiYmQvZG9jdW1lbnRzL3NtYXJ0LWxpdmUtY2hhdC12My1maXhlZDoxNzk0MjYyMDEw.OWQyYzEwYjk4MjE3YTFlNzA2Yjk0YjUzNTJhN2RlOTU";

/* ---------------- helpers ---------------- */
const $ = (id)=>document.getElementById(id);
const esc = (s)=>{ const d=document.createElement('div'); d.appendChild(document.createTextNode(s==null?'':String(s))); return d.innerHTML; };
const initials = (n)=>(n||'?').trim().charAt(0).toUpperCase()||'?';
const convId = (a,b)=>[a,b].sort().join('_');
const now = ()=>Date.now();
const fmtTime = (ts)=>{ if(!ts) return ''; const d=new Date(ts); return String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0'); };
const fmtDay = (ts)=>{
  if(!ts) return '';
  const d=new Date(ts), n=new Date();
  if(d.toDateString()===n.toDateString()) return 'Hari ini';
  const y=new Date(n); y.setDate(n.getDate()-1);
  if(d.toDateString()===y.toDateString()) return 'Kemarin';
  return d.toLocaleDateString('id-ID',{day:'numeric',month:'long',year:'numeric'});
};
function toast(msg, kind){
  const w=$('toast-wrap'); if(!w) return;
  const t=document.createElement('div'); t.className='toast '+(kind||''); t.textContent=msg;
  w.appendChild(t);
  setTimeout(()=>{ t.style.opacity='0'; t.style.transition='.25s'; setTimeout(()=>t.remove(),260); },2800);
}
function bridge(obj){
  try{ if(window.AndroidBridge && window.AndroidBridge.postMessage) window.AndroidBridge.postMessage(JSON.stringify(obj)); }catch(e){}
}
const isNative = ()=>!!window.__SLC_NATIVE__;

/* ---------------- state ---------------- */
const GROUP = { type:'group', id:'group', name:'Public Room', sub:'Grup publik' };
let currentUser=null, activeChat=GROUP, usersCache=[], activeTab='group', searchTerm='';
let unread={group:0, private:{}}, lastSeenMsg={group:'', private:{}};
let msgRef=null, msgHandler=null, usersRef=null, typingRef=null, typingHandler=null;
let seenIds=new Set(), seenReady=false, firstRender=true;
let myProfile={};

/* ---------------- sound ---------------- */
const SOUND_KEY='slc_sound_v2';
let soundCfg={enabled:true, tone:'chime', volume:0.7, sendSound:true};
try{ const s=JSON.parse(localStorage.getItem(SOUND_KEY)||'null'); if(s) soundCfg=Object.assign(soundCfg,s); }catch(e){}
function saveSound(){ try{ localStorage.setItem(SOUND_KEY, JSON.stringify(soundCfg)); }catch(e){} }
let actx=null, audioUnlocked=false;
function audioCtx(){
  if(!actx){ const AC=window.AudioContext||window.webkitAudioContext; if(!AC) return null; try{ actx=new AC(); }catch(e){ return null; } }
  if(actx.state==='suspended'){ try{ actx.resume(); }catch(e){} }
  return actx;
}
function primeAudio(){
  const ctx=audioCtx(); if(!ctx) return false;
  try{ const b=ctx.createBuffer(1,1,22050), s=ctx.createBufferSource(); s.buffer=b; s.connect(ctx.destination); s.start(0); }catch(e){}
  if(ctx.state==='running') audioUnlocked=true;
  updateAudioStatus(); return audioUnlocked;
}
function updateAudioStatus(){
  const el=$('audio-status'); if(!el) return;
  const running=!!(actx&&actx.state==='running');
  if(!actx){ el.className='audio-status bad'; el.textContent='Audio tidak didukung'; }
  else if(running){ el.className='audio-status ok'; el.textContent='Audio aktif — siap berbunyi'; }
  else { el.className='audio-status warn'; el.textContent='Audio belum aktif — ketuk di mana saja'; }
}
['pointerdown','touchstart','mousedown','keydown','click'].forEach(ev=>{
  document.addEventListener(ev, ()=>{ if(!audioUnlocked||!actx||actx.state!=='running') primeAudio(); }, {passive:true});
});
const TONES={
  chime:{label:'Chime',wave:'sine',notes:[[880,0,.16],[1174.66,.11,.20],[1567.98,.22,.34]]},
  pop:{label:'Pop',wave:'sine',notes:[[520,0,.09],[780,.06,.13]]},
  bell:{label:'Bell',wave:'triangle',notes:[[1046.5,0,.5],[1568,.02,.42]]},
  marimba:{label:'Marimba',wave:'triangle',notes:[[659.25,0,.16],[783.99,.10,.16],[1046.5,.20,.30]]},
  ding:{label:'Ding',wave:'sine',notes:[[1318.5,0,.55]]},
  buzz:{label:'Buzz',wave:'square',notes:[[220,0,.10],[196,.12,.10],[220,.24,.14]]}
};
function playTone(name, vol){
  const ctx=audioCtx(); if(!ctx) return;
  const tone=TONES[name]||TONES.chime;
  const level=Math.max(0,Math.min(1, vol==null?soundCfg.volume:vol));
  if(level<=0) return;
  const fire=()=>{
    const master=ctx.createGain(); master.gain.value=level; master.connect(ctx.destination);
    const t0=ctx.currentTime+0.02;
    tone.notes.forEach(([f,d,dur])=>{
      const o=ctx.createOscillator(), g=ctx.createGain();
      o.type=tone.wave; o.frequency.setValueAtTime(f,t0+d);
      g.gain.setValueAtTime(0.0001,t0+d);
      g.gain.exponentialRampToValueAtTime(0.9,t0+d+0.012);
      g.gain.exponentialRampToValueAtTime(0.0001,t0+d+dur);
      o.connect(g); g.connect(master); o.start(t0+d); o.stop(t0+d+dur+0.05);
    });
  };
  if(ctx.state==='running'){ fire(); return; }
  try{ const p=ctx.resume(); if(p&&p.then) p.then(()=>{ audioUnlocked=true; updateAudioStatus(); fire(); }).catch(()=>{}); else fire(); }
  catch(e){ fire(); }
}
const playReceive=()=>{ if(soundCfg.enabled) playTone(soundCfg.tone, soundCfg.volume); };
const playSend=()=>{ if(soundCfg.enabled&&soundCfg.sendSound) playTone('pop', soundCfg.volume*0.45); };
let ringTimer=null;
function startRing(){
  stopRing();
  const ring=()=>{
    const ctx=audioCtx(); if(!ctx) return;
    const t0=ctx.currentTime;
    [0,0.55].forEach(off=>{ [880,1108].forEach(f=>{
      const o=ctx.createOscillator(), g=ctx.createGain();
      o.type='sine'; o.frequency.value=f;
      g.gain.setValueAtTime(0.0001,t0+off);
      g.gain.exponentialRampToValueAtTime(0.22,t0+off+0.03);
      g.gain.exponentialRampToValueAtTime(0.0001,t0+off+0.42);
      o.connect(g); g.connect(ctx.destination); o.start(t0+off); o.stop(t0+off+0.45);
    });});
  };
  ring(); ringTimer=setInterval(ring,1800);
}
function stopRing(){ if(ringTimer){ clearInterval(ringTimer); ringTimer=null; } }

/* ---------------- theme ---------------- */
const THEME_KEY='slc_theme_v2';
const THEMES=[
  {id:'hijau-merah',name:'Hijau Merah',grad:'linear-gradient(115deg,#0A5C42,#0F7B57 24%,#16A34A 44%,#6FA83A 62%,#D9A227 80%,#DC2626)'},
  {id:'biru-ungu',name:'Biru Ungu',grad:'linear-gradient(115deg,#0B2A6B,#1D4ED8 26%,#4F46E5 48%,#7C3AED 70%,#A855F7 88%,#C026D3)'},
  {id:'oranye-pink',name:'Oranye Pink',grad:'linear-gradient(115deg,#7C2D12,#EA580C 26%,#F59E0B 48%,#F472B6 72%,#EC4899 88%,#DB2777)'},
  {id:'teal-gold',name:'Teal Gold',grad:'linear-gradient(115deg,#0F3D3E,#0D9488 26%,#14B8A6 48%,#84CC16 70%,#EAB308 88%,#CA8A04)'},
  {id:'ungu-magenta',name:'Ungu Magenta',grad:'linear-gradient(115deg,#2E1065,#6D28D9 26%,#9333EA 48%,#C026D3 70%,#DB2777 88%,#E11D48)'},
  {id:'sunset',name:'Sunset',grad:'linear-gradient(115deg,#4C1D95,#7C3AED 22%,#DB2777 46%,#F97316 72%,#FBBF24 90%,#FDE68A)'},
  {id:'biru-hijau',name:'Biru Hijau',grad:'linear-gradient(115deg,#052E2B,#0F766E 24%,#0891B2 46%,#0EA5E9 66%,#22C55E 86%,#84CC16)'}
];
let currentTheme='hijau-merah';
try{ const t=localStorage.getItem(THEME_KEY); if(t&&THEMES.some(x=>x.id===t)) currentTheme=t; }catch(e){}
function applyTheme(id){
  if(!THEMES.some(x=>x.id===id)) id='hijau-merah';
  currentTheme=id;
  const root=$('slc-root'); if(root) root.setAttribute('data-theme',id);
  try{ localStorage.setItem(THEME_KEY,id); }catch(e){}
  renderThemes();
}
function renderThemes(){
  const grid=$('theme-grid'); if(!grid) return;
  grid.innerHTML=THEMES.map(t=>`
    <button class="theme-card ${currentTheme===t.id?'active':''}" data-theme-id="${t.id}" type="button">
      <span class="theme-swatch" style="background:${t.grad}"></span>
      <span class="theme-meta"><span class="theme-name">${t.name}</span>
      <span class="theme-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"><path d="m1 12 5 5L18 5"/></svg></span></span>
    </button>`).join('');
  grid.querySelectorAll('.theme-card').forEach(c=>c.addEventListener('click',()=>{
    applyTheme(c.dataset.themeId);
    toast('Tema "'+THEMES.find(x=>x.id===c.dataset.themeId).name+'" diterapkan','ok');
  }));
}

/* ---------------- profile photo ---------------- */
const PHOTO_KEY='slc_photo_v2';
let localPhoto='';
try{ localPhoto=localStorage.getItem(PHOTO_KEY)||''; }catch(e){}
function myPhoto(){ return localPhoto || (currentUser&&currentUser.photoURL) || ''; }
function syncProfileUI(){
  const name=currentUser?(currentUser.displayName||(currentUser.email||'').split('@')[0]):'Belum masuk';
  const mail=currentUser?(currentUser.email||''):'Masuk untuk mengubah profil';
  if($('profile-name')) $('profile-name').textContent=name;
  if($('profile-mail')) $('profile-mail').textContent=mail;
  const av=$('profile-av'); if(!av) return;
  const old=av.querySelector('img'); if(old) old.remove();
  const txt=$('profile-av-text');
  const photo=myPhoto();
  if(photo){
    txt.style.display='none';
    const img=document.createElement('img'); img.alt='';
    img.onerror=()=>{ img.remove(); txt.style.display=''; };
    av.insertBefore(img, av.firstChild); img.src=photo;
  } else { txt.style.display=''; txt.textContent=initials(name); }
  if($('btn-pick-photo')) $('btn-pick-photo').disabled=!currentUser;
  if($('btn-reset-photo')) $('btn-reset-photo').disabled=!currentUser;
}
function refreshMyAvatar(){
  if(!currentUser) return;
  const name=currentUser.displayName||(currentUser.email||'').split('@')[0];
  const av=$('me-avatar'); if(!av) return;
  const photo=myPhoto();
  av.innerHTML=photo?`<img src="${esc(photo)}" alt="" onerror="this.parentElement.textContent='${esc(initials(name))}'">`:esc(initials(name));
}
function compressImage(file,maxSize,quality){
  return new Promise((res,rej)=>{
    const r=new FileReader();
    r.onerror=rej;
    r.onload=()=>{
      const img=new Image();
      img.onerror=rej;
      img.onload=()=>{
        let w=img.width,h=img.height;
        const sc=Math.min(1,maxSize/Math.max(w,h));
        w=Math.round(w*sc); h=Math.round(h*sc);
        const c=document.createElement('canvas'); c.width=w; c.height=h;
        c.getContext('2d').drawImage(img,0,0,w,h);
        res(c.toDataURL('image/jpeg',quality));
      };
      img.src=r.result;
    };
    r.readAsDataURL(file);
  });
}

/* ---------------- settings UI ---------------- */
function renderTones(){
  const wrap=$('tone-list'); if(!wrap) return;
  wrap.innerHTML=Object.keys(TONES).map(k=>`
    <button class="tone ${soundCfg.tone===k?'active':''}" data-tone="${k}">
      <span class="t-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg></span>
      ${TONES[k].label}</button>`).join('');
  wrap.querySelectorAll('.tone').forEach(b=>b.addEventListener('click',()=>{
    soundCfg.tone=b.dataset.tone; saveSound(); renderTones(); playTone(soundCfg.tone,soundCfg.volume);
  }));
}
function syncSettingsUI(){
  if(!$('sw-enabled')) return;
  $('sw-enabled').classList.toggle('on',soundCfg.enabled);
  $('sw-enabled').setAttribute('aria-checked',soundCfg.enabled);
  $('sw-send').classList.toggle('on',soundCfg.sendSound);
  $('sw-send').setAttribute('aria-checked',soundCfg.sendSound);
  $('vol-range').value=Math.round(soundCfg.volume*100);
  $('vol-label').textContent=Math.round(soundCfg.volume*100)+'%';
  renderTones();
}
function openSettings(){
  const ov=$('settings-overlay'); if(!ov) return;
  try{ syncSettingsUI(); }catch(e){}
  try{ syncProfileUI(); }catch(e){}
  try{ renderThemes(); }catch(e){}
  ov.classList.add('show');
  ov.style.setProperty('display','flex','important');
  ov.style.setProperty('z-index','9000','important');
  ov.style.setProperty('position','fixed','important');
  ov.style.setProperty('inset','0','important');
  ov.style.setProperty('visibility','visible','important');
  ov.style.setProperty('opacity','1','important');
  ov.style.setProperty('pointer-events','auto','important');
  updateAudioStatus();
}
function closeSettings(){
  const ov=$('settings-overlay'); if(!ov) return;
  ov.classList.remove('show');
  ['display','z-index','position','inset','visibility','opacity','pointer-events'].forEach(p=>ov.style.removeProperty(p));
}

/* ---------------- auth ---------------- */
function showAuthError(msg){
  const box=$('auth-error'); if(!box) return;
  if(!msg){ box.style.display='none'; box.textContent=''; return; }
  box.style.display='block'; box.textContent=msg;
}
function authErrorMessage(e){
  const code=(e&&e.code)||'', raw=(e&&e.message)||'';
  const map={
    'auth/popup-blocked':'Popup diblokir. Coba lagi.',
    'auth/popup-closed-by-user':'Jendela login ditutup.',
    'auth/operation-not-allowed':'Metode login ini belum diaktifkan di Firebase.',
    'auth/unauthorized-domain':'Domain belum diizinkan di Firebase Authentication.',
    'auth/network-request-failed':'Koneksi ke server login gagal.',
    'auth/invalid-email':'Format email tidak valid.',
    'auth/user-not-found':'Akun tidak ditemukan. Daftar dulu.',
    'auth/wrong-password':'Kata sandi salah.',
    'auth/invalid-credential':'Email atau kata sandi salah.',
    'auth/email-already-in-use':'Email sudah terdaftar. Silakan masuk.',
    'auth/weak-password':'Kata sandi minimal 6 karakter.',
    'auth/too-many-requests':'Terlalu banyak percobaan. Coba lagi nanti.'
  };
  return map[code] || (code?code+' — '+raw:(raw||'Login gagal. Coba lagi.'));
}
async function saveUserProfile(user){
  if(!user) return;
  try{
    await db.ref('users/'+user.uid).update({
      uid:user.uid,
      email:user.email||'',
      displayName:user.displayName||(user.email||'').split('@')[0],
      photoURL:myPhoto()||user.photoURL||'',
      lastSeen:now()
    });
  }catch(e){}
}
async function startGoogleLogin(){
  showAuthError('');
  // Native: pakai Google Sign-In Android (idToken) -> Firebase credential
  if(isNative() && window.AndroidBridge && window.AndroidBridge.googleSignIn){
    try{ window.AndroidBridge.googleSignIn(); return; }catch(e){}
  }
  const provider=new firebase.auth.GoogleAuthProvider();
  provider.setCustomParameters({prompt:'select_account'});
  try{
    const r=await auth.signInWithPopup(provider);
    if(r&&r.user){ await saveUserProfile(r.user); return r.user; }
  }catch(e){
    const code=(e&&e.code)||'';
    const fb=['auth/popup-blocked','auth/popup-closed-by-user','auth/cancelled-popup-request','auth/operation-not-supported-in-this-environment','auth/web-storage-unsupported'];
    if(!fb.includes(code)){ showAuthError(authErrorMessage(e)); return null; }
  }
  try{ await auth.signInWithRedirect(provider); return null; }
  catch(e){ showAuthError(authErrorMessage(e)); return null; }
}
/* dipanggil dari native setelah Google Sign-In berhasil */
window.__slcGoogleToken=async function(json){
  try{
    const d=typeof json==='string'?JSON.parse(json):json;
    if(!d||!d.idToken){ showAuthError('Token Google tidak diterima'); return; }
    const cred=firebase.auth.GoogleAuthProvider.credential(d.idToken);
    const r=await auth.signInWithCredential(cred);
    if(r&&r.user) await saveUserProfile(r.user);
  }catch(e){ showAuthError(authErrorMessage(e)); }
};
window.__slcGoogleError=function(msg){
  const m=String(msg||'');
  // Kode mentah seperti "10:" tidak berguna -> beri penjelasan + arahkan ke email
  if(/^\s*10\s*:?\s*$/.test(m) || /DEVELOPER_ERROR/i.test(m)){
    showAuthError('Login Google belum aktif untuk aplikasi ini (SHA-1 belum didaftarkan di Firebase Console). Silakan masuk dengan email & kata sandi di bawah.');
    highlightEmailFallback();
    return;
  }
  if(/^\s*12501\s*:?\s*$/.test(m)){ showAuthError('Login Google dibatalkan.'); return; }
  if(/^\s*7\s*:?\s*$/.test(m)){ showAuthError('Tidak ada koneksi internet. Periksa jaringan lalu coba lagi.'); return; }
  showAuthError(m||'Login Google dibatalkan');
  highlightEmailFallback();
};
/* sorot opsi email supaya pengguna tidak buntu saat Google gagal */
function highlightEmailFallback(){
  try{
    const link=$('btn-email-toggle')||$('link-email')||document.querySelector('[data-auth-email]');
    if(link){ link.classList.add('pulse'); setTimeout(()=>link.classList.remove('pulse'),4000); }
    const box=$('email-form')||$('email-box');
    if(box && box.style.display==='none'){ /* biarkan pengguna membuka sendiri */ }
  }catch(e){}
}

async function emailAuth(register){
  const email=($('email-input').value||'').trim();
  const pass=($('pass-input').value||'');
  if(!email||!pass){ showAuthError('Isi email dan kata sandi.'); return; }
  showAuthError('');
  try{
    if(register){
      const r=await auth.createUserWithEmailAndPassword(email,pass);
      try{ await r.user.updateProfile({displayName:email.split('@')[0]}); }catch(e){}
      await saveUserProfile(r.user);
    } else {
      const r=await auth.signInWithEmailAndPassword(email,pass);
      await saveUserProfile(r.user);
    }
  }catch(e){ showAuthError(authErrorMessage(e)); }
}

/* ---------------- sidebar / list ---------------- */
function avatarHTML(u, cls){
  const name=u.displayName||u.email||'User';
  return u.photoURL
    ? `<div class="avatar ${cls||''}"><img src="${esc(u.photoURL)}" alt="" onerror="this.parentElement.textContent='${esc(initials(name))}'"></div>`
    : `<div class="avatar ${cls||''}">${esc(initials(name))}</div>`;
}
function renderList(){
  const list=$('chat-list'); if(!list) return;
  const q=searchTerm.toLowerCase();
  let html='';
  if(activeTab==='group'){
    if(!q||GROUP.name.toLowerCase().includes(q)){
      const badge=unread.group>0?`<span class="ci-badge">${unread.group>99?'99+':unread.group}</span>`:'';
      html+=`<div class="list-label">Grup</div>
      <div class="chat-item ${activeChat.type==='group'?'active':''}" data-chat="group">
        <div class="avatar group">S</div>
        <div class="ci-body">
          <div class="ci-top"><span class="ci-name">${GROUP.name}</span><span class="ci-time">${lastSeenMsg.group||''}</span></div>
          <div class="ci-preview">${usersCache.length} anggota · semua bisa mengobrol</div>
        </div>${badge}</div>`;
    }
  } else {
    const others=usersCache.filter(u=>u.uid!==(currentUser&&currentUser.uid));
    const filtered=others.filter(u=>!q||(u.displayName||'').toLowerCase().includes(q)||(u.email||'').toLowerCase().includes(q));
    html+=`<div class="list-label">Chat pribadi · ${others.length}</div>`;
    if(!filtered.length){
      html+=`<div class="empty-list">${others.length===0?'Belum ada pengguna lain yang bergabung.':'Tidak ada hasil untuk "'+esc(searchTerm)+'".'}</div>`;
    } else {
      filtered.forEach(u=>{
        const isActive=activeChat.type==='private'&&activeChat.uid===u.uid;
        const b=unread.private[u.uid]||0;
        html+=`<div class="chat-item ${isActive?'active':''}" data-chat="private" data-uid="${esc(u.uid)}">
          ${avatarHTML(u)}
          <div class="ci-body">
            <div class="ci-top"><span class="ci-name">${esc(u.displayName||'User')}</span><span class="ci-time">${lastSeenMsg.private[u.uid]||''}</span></div>
            <div class="ci-preview">${esc(u.email||'Ketuk untuk chat')}</div>
          </div>${b>0?`<span class="ci-badge">${b>99?'99+':b}</span>`:''}</div>`;
      });
    }
  }
  list.innerHTML=html;
  if($('private-count')) $('private-count').textContent=usersCache.filter(u=>u.uid!==(currentUser&&currentUser.uid)).length;
  list.querySelectorAll('.chat-item').forEach(el=>el.addEventListener('click',()=>{
    if(el.dataset.chat==='group') openGroup();
    else { const u=usersCache.find(x=>x.uid===el.dataset.uid); if(u) openPrivate(u); }
  }));
  updateBadge();
  renderCallLog();
}
function updateBadge(){
  let total=unread.group;
  Object.keys(unread.private).forEach(k=>total+=unread.private[k]||0);
  bridge({type:'badge', count:total});
  try{ if(window.AndroidBridge&&window.AndroidBridge.setBadge) window.AndroidBridge.setBadge(total); }catch(e){}
  const b=$('call-log-badge');
  if(b){
    if(missedCalls>0){ b.textContent=missedCalls>99?'99+':missedCalls; b.style.display=''; }
    else b.style.display='none';
  }
}

/* ---------------- chat open ---------------- */
function setHeader(){
  const av=$('ch-avatar'), isGroup=activeChat.type==='group';
  if(isGroup){
    av.className='avatar group'; av.innerHTML='S';
    $('ch-name').textContent=GROUP.name;
    $('ch-sub').textContent=usersCache.length+' anggota · grup publik';
  } else {
    av.className='avatar';
    av.innerHTML=activeChat.photoURL?`<img src="${esc(activeChat.photoURL)}" alt="" onerror="this.parentElement.textContent='${esc(initials(activeChat.displayName))}'">`:esc(initials(activeChat.displayName));
    $('ch-name').textContent=activeChat.displayName||'User';
    $('ch-sub').textContent='Chat pribadi · terenkripsi antar akun';
  }
  $('btn-voice-call').hidden=isGroup;
  $('btn-video-call').hidden=isGroup;
  $('btn-voice-call').style.display=isGroup?'none':'';
  $('btn-video-call').style.display=isGroup?'none':'';
}
function openGroup(){
  activeChat=GROUP; unread.group=0;
  try{ stopVoice(); }catch(e){}
  $('app').classList.add('chat-open');
  setHeader(); renderList(); loadMessages();
}
function openPrivate(u){
  activeChat={type:'private', uid:u.uid, displayName:u.displayName, photoURL:u.photoURL, email:u.email};
  unread.private[u.uid]=0;
  try{ stopVoice(); }catch(e){}
  $('app').classList.add('chat-open');
  setHeader(); renderList(); loadMessages();
}
window.__slcOpenChat=function(uid){
  const u=usersCache.find(x=>x.uid===uid);
  if(u) openPrivate(u);
  else if(uid) openPrivate({uid:uid, displayName:'Pengguna', photoURL:'', email:''});
};

/* ---------------- messages ---------------- */
function linkify(text){
  if(!text) return '';
  return esc(text).replace(/(https?:\/\/[^\s<]+|www\.[^\s<]+)/gi,(m)=>{
    const href=m.startsWith('http')?m:'https://'+m;
    return `<a href="${href}" target="_blank" rel="noopener noreferrer">${m}</a>`;
  });
}
function senderColor(uid){
  const colors=['#0E7C5A','#1D4ED8','#B45309','#7C3AED','#BE123C','#0F766E','#C2410C'];
  let h=0; for(let i=0;i<(uid||'').length;i++) h=(h*31+uid.charCodeAt(i))>>>0;
  return colors[h%colors.length];
}
function isVoiceMsg(d){
  const t=(d.fileType||'')+' '+(d.fileName||'');
  return /audio|\.mp3|\.m4a|\.wav|\.ogg|\.webm|\.aac/i.test(t);
}
function bubbleHTML(d, isMe, showSender, showAvatar, senderName, senderPhoto){
  const time=fmtTime(d.ts);
  let inner='';
  if(showSender&&!isMe) inner+=`<span class="b-sender" style="color:${senderColor(d.senderId)}">${esc(senderName)}</span>`;
  if(d.fileURL){
    if(d.isImage){
      inner+=`<img class="b-img" src="${esc(d.fileURL)}" alt="${esc(d.fileName||'gambar')}" loading="lazy" data-full="${esc(d.fileURL)}">`;
    } else if(isVoiceMsg(d)){
      inner+=`<div class="b-voice" data-audio-src="${esc(d.fileURL)}" data-audio-id="${esc(d.id||'')}">
        <button class="bv-play" type="button" aria-label="Putar pesan suara">
          <svg class="bv-ic-play" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M8 5.14v13.72a1 1 0 0 0 1.5.86l11-6.86a1 1 0 0 0 0-1.72l-11-6.86A1 1 0 0 0 8 5.14z"/></svg>
          <svg class="bv-ic-pause" viewBox="0 0 24 24" fill="currentColor" stroke="none"><rect x="6" y="4" width="4" height="16" rx="1.2"/><rect x="14" y="4" width="4" height="16" rx="1.2"/></svg>
        </button>
        <div class="bv-body"><div class="bv-track"><div class="bv-fill"></div></div>
        <div class="bv-time"><span class="bv-cur">0:00</span><span class="bv-dur">--:--</span></div></div></div>`;
    } else {
      inner+=`<a class="b-file" href="${esc(d.fileURL)}" target="_blank" rel="noopener noreferrer">
        <span class="fi"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/></svg></span>
        <span>${esc(d.fileName||'File')}</span></a>`;
    }
  }
  if(d.text&&d.text.trim()) inner+=`<span class="b-text">${linkify(d.text)}</span>`;
  let tick='';
  if(isMe){
    const read=!!(d.readBy&&Object.keys(d.readBy).some(k=>k!==currentUser.uid));
    tick=read
      ? `<svg class="tick-read" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="m1 12 5 5L18 5"/><path d="m8 12 5 5L23 5"/></svg>`
      : `<svg class="tick-sent" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="m1 12 5 5L18 5"/></svg>`;
  }
  inner+=`<span class="b-meta">${time}${tick}</span>`;
  const av=isMe?'':(showAvatar
    ? `<div class="msg-av">${senderPhoto?`<img src="${esc(senderPhoto)}" alt="" onerror="this.parentElement.textContent='${esc(initials(senderName))}'">`:esc(initials(senderName))}</div>`
    : `<div class="msg-av hidden"></div>`);
  const del=isMe?`<button class="msg-del" data-del-id="${esc(d.id||'')}" title="Hapus pesan" aria-label="Hapus pesan"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/></svg></button>`:'';
  return `<div class="msg-row ${isMe?'sent':'received'} ${showAvatar?'first':''}">${av}
    <div class="bubble ${isMe?'sent':'received'}">${inner}</div>${del}</div>`;
}
function renderMessages(docs, opts){
  const box=$('messages'); if(!box) return;
  const atBottom=box.scrollHeight-box.scrollTop-box.clientHeight<120;
  box.innerHTML='';
  if(!docs.length){
    box.innerHTML=`<div class="empty-state">
      <div class="es-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg></div>
      <h3>Belum ada pesan</h3>
      <p>${opts.private?'Mulai percakapan pribadi dengan '+esc(opts.name)+'.':'Jadilah yang pertama menyapa di grup ini.'}</p></div>`;
    return;
  }
  let lastDay='', lastSender='', lastTs=0;
  docs.forEach(d=>{
    const day=fmtDay(d.ts);
    if(day&&day!==lastDay){ box.insertAdjacentHTML('beforeend',`<div class="day-sep">${esc(day)}</div>`); lastDay=day; lastSender=''; }
    const isMe=currentUser&&d.senderId===currentUser.uid;
    const ts=d.ts||0;
    const showAvatar=!isMe&&(d.senderId!==lastSender||ts-lastTs>5*60*1000);
    box.insertAdjacentHTML('beforeend', bubbleHTML(d,isMe,showAvatar,showAvatar,d.senderName||'User',d.senderPhoto));
    lastSender=d.senderId; lastTs=ts;
  });
  box.querySelectorAll('img.b-img').forEach(img=>img.addEventListener('click',()=>{
    $('lightbox-img').src=img.dataset.full||img.src; $('lightbox').classList.add('show');
  }));
  box.querySelectorAll('.msg-del').forEach(btn=>btn.addEventListener('click',e=>{ e.stopPropagation(); askDeleteMessage(btn.dataset.delId); }));
  bindVoicePlayers(box);
  if(atBottom||firstRender) box.scrollTop=box.scrollHeight;
  firstRender=false;
}
function msgPath(){
  return activeChat.type==='private'
    ? 'chats/'+convId(currentUser.uid, activeChat.uid)+'/messages'
    : 'messages';
}
function loadMessages(){
  const box=$('messages');
  firstRender=true;
  box.innerHTML=`<div class="empty-state"><div class="es-icon"><span class="spinner" style="width:22px;height:22px;border-width:3px"></span></div><h3>Memuat pesan</h3><p>Sebentar ya...</p></div>`;
  if(msgRef){ msgRef.off('value', msgHandler); msgRef=null; }
  if(typingRef){ typingRef.off('value', typingHandler); typingRef=null; }
  if(!currentUser) return;

  msgRef=db.ref(msgPath()).limitToLast(200);
  msgHandler=msgRef.on('value', snap=>{
    const docs=[];
    snap.forEach(ch=>{
      const d=ch.val()||{};
      if(d.deleted===true||d.hidden===true) return;
      if((d.text&&d.text.trim())||d.fileURL){ d.id=ch.key; docs.push(d); }
    });
    docs.sort((a,b)=>(a.ts||0)-(b.ts||0));
    renderMessages(docs,{private:activeChat.type==='private', name:activeChat.displayName});
    handleIncoming(docs);
    markRead(docs);
  }, err=>{
    box.innerHTML=`<div class="empty-state"><h3>Gagal memuat</h3><p>${esc(err.message)}</p></div>`;
  });

  // typing indicator
  const tPath = activeChat.type==='private'
    ? 'typing/'+convId(currentUser.uid, activeChat.uid)
    : 'typing/group';
  typingRef=db.ref(tPath);
  typingHandler=typingRef.on('value', snap=>{
    const v=snap.val()||{};
    const names=Object.keys(v).filter(k=>k!==currentUser.uid && (now()-(v[k].ts||0)<6000)).map(k=>v[k].name||'Seseorang');
    const bar=$('typing-bar');
    if(!bar) return;
    if(names.length){ bar.textContent=names.slice(0,2).join(', ')+(names.length>2?' dan lainnya':'')+' sedang mengetik…'; bar.classList.add('on'); }
    else { bar.classList.remove('on'); bar.textContent=''; }
  });
}
function markRead(docs){
  if(!currentUser) return;
  const updates={};
  docs.forEach(d=>{
    if(d.senderId===currentUser.uid) return;
    if(d.readBy&&d.readBy[currentUser.uid]) return;
    updates[msgPath()+'/'+d.id+'/readBy/'+currentUser.uid]=true;
  });
  if(Object.keys(updates).length) db.ref().update(updates).catch(()=>{});
}

/* ---------------- incoming / notifications ---------------- */
function handleIncoming(docs){
  const ids=docs.map(d=>d.id);
  if(!seenReady){ ids.forEach(i=>seenIds.add(i)); seenReady=true; return; }
  const fresh=docs.filter(d=>!seenIds.has(d.id));
  ids.forEach(i=>seenIds.add(i));
  if(!fresh.length) return;
  const others=fresh.filter(d=>!currentUser||d.senderId!==currentUser.uid);
  if(!others.length) return;
  const last=others[others.length-1];
  const isActive=(activeChat.type==='group'&&msgPath()==='messages')||(activeChat.type==='private'&&activeChat.uid===last.senderId);
  const visible=document.visibilityState==='visible'&&document.hasFocus();
  if(!(isActive&&visible)){
    playReceive();
    if(activeChat.type==='group') unread.group+=others.length;
    else unread.private[last.senderId]=(unread.private[last.senderId]||0)+others.length;
    renderList();
    notify(last.senderName||'Pesan baru', last.text||(last.isImage?'📷 Gambar':'📄 File'), last.senderId);
  }
}
function notify(title, body, uid){
  if(isNative()){ bridge({type:'notify', title:title, body:body, uid:uid||''}); return; }
  if(!('Notification' in window)||Notification.permission!=='granted') return;
  if(document.visibilityState==='visible'&&document.hasFocus()) return;
  try{
    const n=new Notification(title,{body:(body||'').substring(0,80),tag:'slc-'+uid});
    n.onclick=()=>{ window.focus(); n.close(); };
    setTimeout(()=>n.close(),6000);
  }catch(e){}
}

/* ---------------- send ---------------- */
const input=()=>$('msg-input');
function wireComposer(){
  const inp=input();
  inp.addEventListener('input',()=>{
    inp.style.height='auto';
    inp.style.height=Math.min(inp.scrollHeight,120)+'px';
    setTyping();
  });
  inp.addEventListener('keydown',e=>{ if(e.key==='Enter'&&!e.shiftKey){ e.preventDefault(); sendMsg(); } });
  $('btn-send').addEventListener('click',sendMsg);
}
let typingTimer=null;
function setTyping(){
  if(!currentUser) return;
  const path=activeChat.type==='private'?'typing/'+convId(currentUser.uid,activeChat.uid)+'/'+currentUser.uid:'typing/group/'+currentUser.uid;
  const name=currentUser.displayName||(currentUser.email||'').split('@')[0];
  db.ref(path).set({name:name, ts:now()}).catch(()=>{});
  clearTimeout(typingTimer);
  typingTimer=setTimeout(()=>{ db.ref(path).remove().catch(()=>{}); },4000);
}
async function sendMsg(){
  const inp=input();
  const text=inp.value.trim();
  if(!text||!currentUser) return;
  inp.value=''; inp.style.height='auto';
  const payload={
    text:text,
    senderId:currentUser.uid,
    senderName:currentUser.displayName||(currentUser.email||'').split('@')[0],
    senderPhoto:myPhoto()||'',
    ts:now(),
    status:'sent'
  };
  try{
    const ref=db.ref(msgPath()).push();
    await ref.set(payload);
    if(activeChat.type==='private'){
      const cid=convId(currentUser.uid,activeChat.uid);
      await db.ref('chats/'+cid+'/meta').update({
        participants:{[currentUser.uid]:true,[activeChat.uid]:true},
        lastMessage:text, lastTs:now(), lastSender:currentUser.uid
      });
    } else {
      await db.ref('group_meta').update({lastMessage:text, lastTs:now(), lastSender:currentUser.uid});
    }
    playSend();
    const tp=activeChat.type==='private'?'typing/'+convId(currentUser.uid,activeChat.uid)+'/'+currentUser.uid:'typing/group/'+currentUser.uid;
    db.ref(tp).remove().catch(()=>{});
  }catch(err){
    toast('Gagal mengirim: '+err.message,'err');
    inp.value=text;
  }
}

/* ---------------- attach ---------------- */
function wireAttach(){
  $('btn-attach').addEventListener('click',()=>$('file-input').click());
  $('file-input').addEventListener('change', async function(){
    const file=this.files[0]; this.value='';
    if(!file||!currentUser) return;
    if(file.size>10*1024*1024){ toast('Ukuran file maksimal 10MB','err'); return; }
    const bar=$('upload-bar'), txt=$('upload-text');
    bar.classList.add('show'); txt.textContent='Menyiapkan '+file.name+'...';
    const isImage=file.type.startsWith('image/');
    let fileURL=null;
    if(isImage&&file.size<900*1024){
      try{ fileURL=await new Promise((res,rej)=>{ const r=new FileReader(); r.onload=()=>res(r.result); r.onerror=rej; r.readAsDataURL(file); }); }catch(e){}
    }
    if(!fileURL){
      try{
        txt.textContent='Mengunggah '+file.name+'...';
        const ref=storage.ref('chat_files/'+currentUser.uid+'_'+Date.now()+'_'+file.name);
        const snap=await ref.put(file);
        fileURL=await snap.ref.getDownloadURL();
      }catch(err){
        if(isImage){
          try{ txt.textContent='Mode langsung...'; fileURL=await new Promise((res,rej)=>{ const r=new FileReader(); r.onload=()=>res(r.result); r.onerror=rej; r.readAsDataURL(file); }); }
          catch(e2){ bar.classList.remove('show'); toast('Gagal upload: '+err.message,'err'); return; }
        } else { bar.classList.remove('show'); toast('Gagal upload: '+err.message,'err'); return; }
      }
    }
    const payload={
      text:'', fileURL:fileURL, fileName:file.name, fileType:file.type, isImage:isImage,
      senderId:currentUser.uid,
      senderName:currentUser.displayName||(currentUser.email||'').split('@')[0],
      senderPhoto:myPhoto()||'',
      ts:now(), status:'sent'
    };
    try{
      await db.ref(msgPath()).push().set(payload);
      if(activeChat.type==='private'){
        const cid=convId(currentUser.uid,activeChat.uid);
        await db.ref('chats/'+cid+'/meta').update({
          participants:{[currentUser.uid]:true,[activeChat.uid]:true},
          lastMessage:isImage?'📷 Gambar':'📄 '+file.name, lastTs:now(), lastSender:currentUser.uid
        });
      }
      playSend();
    }catch(e){ toast('Gagal menyimpan: '+e.message,'err'); }
    bar.classList.remove('show');
  });
}

/* ---------------- delete message ---------------- */
let pendingDelId=null, delBusy=false;
function askDeleteMessage(id){
  if(!id||!currentUser) return;
  const ref=db.ref(msgPath()+'/'+id);
  ref.once('value').then(snap=>{
    if(!snap.exists()){ toast('Pesan sudah tidak ada','err'); return; }
    const owner=(snap.val()||{}).senderId;
    if(owner&&owner!==currentUser.uid){ toast('Hanya pemilik pesan yang bisa menghapus','err'); return; }
    pendingDelId=id;
    $('delmsg-overlay').classList.add('show');
  }).catch(err=>toast('Gagal memeriksa pesan: '+err.message,'err'));
}
function closeDelMsg(){ $('delmsg-overlay').classList.remove('show'); pendingDelId=null; }
function wireDelete(){
  $('btn-close-delmsg').addEventListener('click',closeDelMsg);
  $('btn-cancel-delmsg').addEventListener('click',closeDelMsg);
  $('delmsg-overlay').addEventListener('click',e=>{ if(e.target===$('delmsg-overlay')) closeDelMsg(); });
  $('btn-confirm-delmsg').addEventListener('click',async ()=>{
    if(delBusy||!pendingDelId) return;
    const id=pendingDelId, btn=$('btn-confirm-delmsg');
    delBusy=true; btn.disabled=true; const label=btn.textContent; btn.textContent='Menghapus...';
    try{ await db.ref(msgPath()+'/'+id).remove(); closeDelMsg(); toast('Pesan dihapus','ok'); }
    catch(err){ toast('Gagal menghapus: '+err.message,'err'); }
    finally{ btn.disabled=false; btn.textContent=label; delBusy=false; }
  });
}

/* ---------------- voice message player ---------------- */
let currentAudio=null, currentWrap=null;
function bindVoicePlayers(root){
  root.querySelectorAll('.b-voice').forEach(w=>{
    const btn=w.querySelector('.bv-play');
    const src=w.dataset.audioSrc;
    const dur=w.querySelector('.bv-dur');
    const cur=w.querySelector('.bv-cur');
    const fill=w.querySelector('.bv-fill');
    if(!btn||!src) return;
    btn.addEventListener('click',()=>{
      if(currentAudio&&currentWrap===w){
        if(currentAudio.paused){ currentAudio.play(); w.classList.add('playing'); }
        else { currentAudio.pause(); w.classList.remove('playing'); }
        return;
      }
      if(currentAudio){ try{ currentAudio.pause(); }catch(e){} if(currentWrap) currentWrap.classList.remove('playing'); }
      const a=new Audio(src);
      currentAudio=a; currentWrap=w;
      a.addEventListener('loadedmetadata',()=>{ if(isFinite(a.duration)) dur.textContent=fmtDur(a.duration); });
      a.addEventListener('timeupdate',()=>{
        cur.textContent=fmtDur(a.currentTime);
        if(a.duration) fill.style.width=Math.min(100,(a.currentTime/a.duration)*100)+'%';
      });
      a.addEventListener('ended',()=>{ w.classList.remove('playing'); fill.style.width='0%'; cur.textContent='0:00'; });
      a.play().then(()=>w.classList.add('playing')).catch(()=>toast('Tidak bisa memutar audio','err'));
    });
  });
}
function fmtDur(s){ s=Math.max(0,Math.floor(s||0)); return Math.floor(s/60)+':'+String(s%60).padStart(2,'0'); }

/* ============================================================
   PUSH (FCM data-message) + RIWAYAT PANGGILAN
   ------------------------------------------------------------
   Signaling panggilan memakai Realtime Database + PeerJS. Itu hanya
   bekerja kalau KEDUA sisi sedang membuka aplikasi. Supaya panggilan
   tetap sampai saat penerima offline / aplikasi tertutup, pengirim
   mengirim data-message FCM ke token penerima; FcmService di sisi
   native menampilkan layar panggilan masuk (full-screen intent).
   ============================================================ */
let _serverKeyCache = null;
let _saCache = null;
let _fcmSeq = 0;
const _fcmWaiters = new Map();

/* Hasil pengiriman dari sisi native (FcmSender) masuk lewat sini. */
window.__slcFcmResult = function(res){
  try{
    const d = typeof res === 'string' ? JSON.parse(res) : res;
    const w = _fcmWaiters.get(d && d.id);
    if(w){ _fcmWaiters.delete(d.id); w(d); }
  }catch(e){}
};

/* Service account JSON untuk FCM HTTP v1.
   Disimpan admin di /config/fcmServiceAccount (string JSON).
   Kunci ini TIDAK disimpan di dalam APK dan tidak mengubah
   konfigurasi Firebase yang sudah ada. */
async function fcmServiceAccount(){
  if(_saCache !== null) return _saCache;
  try{
    const snap = await db.ref('config/fcmServiceAccount').once('value');
    const v = snap.val();
    if(typeof v === 'string' && v.indexOf('private_key') >= 0) _saCache = v;
    else if(v && typeof v === 'object' && v.private_key) _saCache = JSON.stringify(v);
    else _saCache = '';
  }catch(e){ _saCache = ''; }
  return _saCache;
}

/* Server key legacy (opsional, sudah usang tapi masih jalan untuk
   project lama). Kalau admin menaruh di /config/fcmServerKey. */
async function fcmServerKey(){
  if(_serverKeyCache !== null) return _serverKeyCache;
  try{
    const snap = await db.ref('config/fcmServerKey').once('value');
    const v = snap.val();
    _serverKeyCache = (typeof v === 'string' && v.length > 20) ? v : '';
  }catch(e){ _serverKeyCache = ''; }
  return _serverKeyCache;
}

/* Kirim satu data-message FCM high-priority. true kalau server menerima.

   PENTING: penandatanganan JWT RS256 dilakukan di sisi native
   (AndroidBridge.sendFcm). WebView di sini berjalan dari
   file:///android_asset yang BUKAN secure context, jadi
   window.crypto.subtle tidak tersedia dan JWT tidak bisa dibuat di JS.
   Sebelumnya kode ini mengirim ID token Firebase Auth ke FCM v1; ID token
   tidak pernah punya scope cloudmessaging.messages.create sehingga FCM
   selalu menjawab 401/403 dan tidak ada push yang pernah terkirim. */
async function sendFcmTo(token, data){
  if(!token) return false;

  // Jalur 1 (utama): native FcmSender + service account.
  if(isNative() && window.AndroidBridge && window.AndroidBridge.sendFcm){
    const sa = await fcmServiceAccount();
    if(sa){
      const id = 'f' + (++_fcmSeq);
      const p = new Promise(resolve=>{
        _fcmWaiters.set(id, resolve);
        setTimeout(()=>{ if(_fcmWaiters.has(id)){ _fcmWaiters.delete(id); resolve({ok:false, detail:'timeout'}); } }, 15000);
      });
      try{
        window.AndroidBridge.sendFcm(sa, token, JSON.stringify(data), id);
        const r = await p;
        if(r && r.ok) return true;
        console.warn('FCM native gagal:', r && r.detail);
      }catch(e){ console.warn('FCM native error:', e); }
    }
  }

  // Jalur 2: legacy server key (kalau tersedia).
  try{
    const sk = await fcmServerKey();
    if(sk){
      /* v13 DATA-ONLY: TIDAK ada field "notification" / "android.notification".
         Kalau ada field notification, FCM SDK sendiri yang menampilkan
         notifikasi sistem dan onMessageReceived TIDAK dipanggil -> full-screen
         intent di FcmService tidak pernah terpasang. */
      const body = { to: token, data: data, priority:'high', time_to_live:45 };
      const r2 = await fetch('https://fcm.googleapis.com/fcm/send', {
        method:'POST',
        headers:{ 'Content-Type':'application/json', 'Authorization':'key=' + sk },
        body: JSON.stringify(body)
      });
      return r2.ok;
    }
  }catch(e){}
  return false;
}

/* Ambil token FCM penerima. Mendukung format lama (string) dan
   format baru (map token -> true) supaya multi-perangkat jalan. */
async function fcmTokenOf(uid){
  try{
    const snap = await db.ref('users/' + uid).once('value');
    const u = snap.val() || {};
    if(typeof u.fcmToken === 'string' && u.fcmToken.length > 10) return u.fcmToken;
    const map = u.fcmTokens;
    if(map && typeof map === 'object'){
      const keys = Object.keys(map).filter(k=>k.length > 10);
      if(keys.length) return keys[keys.length - 1];
    }
    return null;
  }catch(e){ return null; }
}

/* Semua token penerima (multi-perangkat). */
async function fcmTokensOf(uid){
  try{
    const snap = await db.ref('users/' + uid).once('value');
    const u = snap.val() || {};
    const out = [];
    if(typeof u.fcmToken === 'string' && u.fcmToken.length > 10) out.push(u.fcmToken);
    const map = u.fcmTokens;
    if(map && typeof map === 'object'){
      Object.keys(map).forEach(k=>{ if(k.length > 10 && out.indexOf(k) < 0) out.push(k); });
    }
    return out;
  }catch(e){ return []; }
}

/* Kirim push "panggilan masuk" ke semua perangkat penerima. */
async function pushIncomingCall(uid, callId, kind, callerName, callerPhoto){
  const tokens = await fcmTokensOf(uid);
  if(!tokens.length){ console.warn('FCM: penerima belum punya token tersimpan'); return false; }
  /* PENTING: payload HARUS memakai nama key yang dibaca FcmService native
     (type=incoming_call, call_id, room_id, token, caller_name, caller_avatar).
     Sebelumnya dikirim type='call' + callId, sehingga FcmService tidak
     mengenalinya dan CallService tidak pernah dijalankan -> panggilan tidak
     bisa diterima saat app di background/killed. */
  /* v13 DATA-ONLY (final).
     Empat field wajib di dalam data: type, callerName, callerId, channel.
     TIDAK ada blok "notification" sama sekali — baik di sini maupun di
     FcmSender native. Dengan data-only, FCM SDK selalu memanggil
     onMessageReceived (termasuk saat app di background/killed), sehingga
     FcmService bisa memasang setFullScreenIntent ke CallActivity.
     Field tambahan (call_id/call_type/caller_avatar) dibaca FcmService. */
  const data = {
    type:'call',
    callerName: callerName || '',
    callerId: currentUser.uid,
    channel: 'call_channel_v2',
    call_id: callId,
    room_id: callId,
    call_type: kind,
    caller_avatar: callerPhoto || '',
    callId: callId,
    callType: kind,
    callerPhoto: callerPhoto || ''
  };
  let ok = false;
  for(const t of tokens){
    try{ if(await sendFcmTo(t, data)) ok = true; }catch(e){}
  }
  return ok;
}

/* Kirim push "panggilan dibatalkan" supaya layar panggilan masuk
   di perangkat penerima ikut tertutup. */
async function pushCallCancelled(uid, callId){
  const tokens = await fcmTokensOf(uid);
  if(!tokens.length) return false;
  const data = {
    type:'call_cancel',
    call_id: callId,
    callId: callId,
    caller_id: currentUser.uid,
    callerId: currentUser.uid
  };
  let ok = false;
  for(const t of tokens){
    try{ if(await sendFcmTo(t, data)) ok = true; }catch(e){}
  }
  return ok;
}

/* ---------------- riwayat panggilan ---------------- */
let callLogRef = null, callLogHandler = null, callLog = [];
let missedCalls = 0;

function callLogPath(){
  return currentUser ? ('callLog/' + currentUser.uid) : null;
}

function loadCallLog(){
  if(callLogRef && callLogHandler){ callLogRef.off('value', callLogHandler); callLogRef = null; }
  const p = callLogPath();
  if(!p) return;
  callLogRef = db.ref(p).limitToLast(100);
  callLogHandler = callLogRef.on('value', snap=>{
    callLog = [];
    snap.forEach(ch=>{ const v = ch.val() || {}; v.id = ch.key; callLog.push(v); });
    callLog.sort((a,b)=>(b.atMs||0)-(a.atMs||0));
    missedCalls = callLog.filter(e=>e.missed && !e.seen).length;
    renderList();
    renderCallLog();
  }, ()=>{});
}

/* Catat satu entri riwayat panggilan. */
function logCall(entry){
  if(!currentUser) return;
  const p = callLogPath();
  if(!p) return;
  const ref = db.ref(p).push();
  const data = Object.assign({
    atMs: now(),
    direction: 'out',
    kind: 'voice',
    peerUid: '',
    peerName: '',
    peerPhoto: '',
    missed: false,
    seen: true,
    durationMs: 0
  }, entry || {});
  ref.set(data).catch(()=>{});
}

/* Tandai panggilan tak terjawab sebagai sudah dilihat. */
function markMissedSeen(){
  if(!currentUser || !missedCalls) return;
  const p = callLogPath();
  if(!p) return;
  callLog.filter(e=>e.missed && !e.seen).forEach(e=>{
    db.ref(p + '/' + e.id).update({ seen:true }).catch(()=>{});
  });
}

function fmtDuration(ms){
  const s = Math.max(0, Math.round((ms||0)/1000));
  return String(Math.floor(s/60)).padStart(2,'0') + ':' + String(s%60).padStart(2,'0');
}

function renderCallLog(){
  const box = $('call-log-list');
  if(!box) return;
  if(!callLog.length){
    box.innerHTML = '<div class="empty-list">Belum ada riwayat panggilan.</div>';
    return;
  }
  let html = '';
  callLog.forEach(e=>{
    const name = e.peerName || 'Pengguna';
    const dir = e.direction === 'in' ? 'Masuk' : 'Keluar';
    const kindTxt = e.kind === 'video' ? 'Video' : 'Suara';
    let status;
    if(e.missed) status = e.direction === 'in' ? 'Tak terjawab' : 'Tidak tersambung';
    else if(e.durationMs > 0) status = fmtDuration(e.durationMs);
    else status = 'Selesai';
    const cls = e.missed ? 'missed' : '';
    const av = e.peerPhoto
      ? '<div class="avatar"><img src="' + esc(e.peerPhoto) + '" alt=""></div>'
      : '<div class="avatar">' + esc(initials(name)) + '</div>';
    html += '<div class="call-item ' + cls + '">' + av +
      '<div class="ci-body">' +
        '<div class="ci-top"><span class="ci-name">' + esc(name) + '</span>' +
        '<span class="ci-time">' + esc(fmtTime(e.atMs)) + '</span></div>' +
        '<div class="ci-preview">' + esc(dir + ' \u00b7 ' + kindTxt + ' \u00b7 ' + status) + '</div>' +
      '</div></div>';
  });
  box.innerHTML = html;
}

function openCallLog(){
  markMissedSeen();
  renderCallLog();
  const ov = $('call-log-overlay');
  if(ov) ov.classList.add('show');
}
function closeCallLog(){
  const ov = $('call-log-overlay');
  if(ov) ov.classList.remove('show');
}

/* Panggilan tak terjawab yang belum dilihat -> beri tahu saat online. */
function notifyMissedCalls(){
  if(!missedCalls) return;
  const last = callLog.find(e=>e.missed && !e.seen);
  if(!last) return;
  notify('Panggilan tak terjawab',
         (last.peerName || 'Seseorang') + ' menelepon (' + (last.kind === 'video' ? 'video' : 'suara') + ')',
         last.peerUid || '');
}

/* ============================================================
   CALLS (PeerJS + Realtime Database signaling)
   ============================================================ */
let peer=null, myPeerId=null;
let call={active:false,id:null,kind:'voice',stream:null,calls:[],remoteStreams:new Map(),
  micOn:true,camOn:true,facing:'user',startedAt:0,timer:null,isCaller:false,target:null,participants:0};
let pendingIncoming=null, declinedCalls=new Set(), callTimeout=null, incomingTimeout=null;
let callRef=null, callHandler=null, callsQuery=null, callsQueryHandler=null;

const ICE_SERVERS=[
  {urls:'stun:stun.l.google.com:19302'},
  {urls:'turn:openrelay.metered.ca:80',username:'openrelayproject',credential:'openrelayproject'},
  {urls:'turn:openrelay.metered.ca:443',username:'openrelayproject',credential:'openrelayproject'},
  {urls:'turn:global.relay.metered.ca:80',username:'302ba12bb38aec282954d31b',credential:'xpbm007Lnu13rbaM'},
  {urls:'turn:global.relay.metered.ca:443',username:'302ba12bb38aec282954d31b',credential:'xpbm007Lnu13rbaM'}
];
function ensurePeerReady(timeoutMs){
  return new Promise(resolve=>{
    if(myPeerId) return resolve(myPeerId);
    if(!currentUser) return resolve(null);
    initPeer();
    const t0=Date.now();
    const iv=setInterval(()=>{
      if(myPeerId){ clearInterval(iv); resolve(myPeerId); }
      else if(Date.now()-t0>(timeoutMs||12000)){ clearInterval(iv); resolve(null); }
    },200);
  });
}
function dialPeer(peerId){
  if(!peer||!call.stream||!peerId) return;
  if(call.calls.some(c=>c.peer===peerId)) return;
  try{ const mc=peer.call(peerId, call.stream); if(mc) attachRemote(mc); }catch(e){}
}
function initPeer(){
  if(peer||!currentUser) return;
  peer=new Peer(null,{debug:0,config:{iceServers:ICE_SERVERS}});
  peer.on('open',id=>{
    myPeerId=id;
    db.ref('users/'+currentUser.uid).update({peerId:id}).catch(()=>{});
    pushIdentity();
  });
  peer.on('disconnected',()=>{ try{ peer.reconnect(); }catch(e){} });
  peer.on('error',err=>{
    if(err.type==='peer-unavailable'){
      const pid=call._callingPeer;
      if(call.active&&call.isCaller&&call.stream&&pid){
        call._retry=call._retry||{};
        call._retry[pid]=(call._retry[pid]||0)+1;
        if(call._retry[pid]<=4){ setTimeout(()=>{ if(call.active&&call.isCaller) dialPeer(pid); },1500); return; }
      }
      toast('Pengguna tidak dapat dihubungi','err');
    }
    if(err.type==='network'||err.type==='server-error'||err.type==='socket-error'){
      try{ peer.destroy(); }catch(e){}
      peer=null; myPeerId=null;
      setTimeout(()=>{ if(currentUser) initPeer(); },1500);
    }
  });
  peer.on('call',incoming=>{
    if(call.active&&call.stream){ incoming.answer(call.stream); attachRemote(incoming); }
    else if(pendingIncoming){ pendingIncoming.mediaConn=incoming; }
    else {
      pendingIncoming=pendingIncoming||{mediaConn:incoming};
      setTimeout(()=>{
        if(pendingIncoming&&pendingIncoming.mediaConn===incoming&&!pendingIncoming.id){
          try{ incoming.close(); }catch(e){}
          pendingIncoming=null;
        }
      },12000);
    }
  });
}
function attachRemote(mc){
  call.calls.push(mc);
  mc.on('stream',remote=>{
    call.remoteStreams.set(mc.peer,remote);
    const v=$('call-remote');
    v.srcObject=remote; v.classList.add('on');
    $('call-voice').classList.add('hide');
    $('call-status').textContent='Terhubung';
    if(!call.startedAt) startTimer();
  });
  mc.on('close',()=>{ if(call.active) endCall(true); });
}
function getMedia(kind){
  const constraints=kind==='video'
    ? {audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true},
       video:{facingMode:call.facing,width:{ideal:1280},height:{ideal:720}}}
    : {audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true},video:false};
  return navigator.mediaDevices.getUserMedia(constraints);
}
function setVoiceState(state){
  const v=$('call-voice'); if(!v) return;
  v.classList.remove('waiting','live','muted'); v.classList.add(state||'waiting');
}
function showCallUI(kind,name,photo,statusText){
  $('call-kind-text').textContent=kind==='video'?'Panggilan video':'Panggilan suara';
  $('call-name').textContent=name;
  $('call-status').textContent=statusText||'Menghubungkan...';
  $('call-timer').textContent='00:00';
  const av=$('call-avatar');
  av.innerHTML=photo?`<img src="${esc(photo)}" alt="">`:esc(initials(name));
  $('call-remote').classList.remove('on'); $('call-remote').srcObject=null;
  $('call-voice').classList.remove('hide'); setVoiceState('waiting');
  $('call-local').classList.toggle('on',kind==='video');
  $('cc-cam').style.display=kind==='video'?'':'none';
  $('cc-switch').style.display=(kind==='video'&&/Mobi|Android/i.test(navigator.userAgent))?'':'none';
  $('call-screen').classList.add('show');
}
function startTimer(){
  call.startedAt=Date.now();
  clearInterval(call.timer);
  call.timer=setInterval(()=>{
    const s=Math.floor((Date.now()-call.startedAt)/1000);
    $('call-timer').textContent=String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0');
  },1000);
}
async function startCall(kind){
  if(!currentUser){ toast('Masuk dulu untuk menelepon','err'); return; }
  if(activeChat.type!=='private'){ toast('Panggilan hanya tersedia di chat pribadi','err'); return; }
  if(call.active) return;
  const readyId=await ensurePeerReady(12000);
  if(!readyId){ toast('Koneksi panggilan belum siap. Periksa internet.','err'); return; }

  call.active=true; call.kind=kind; call.isCaller=true; call.scope='private';
  call.target=activeChat.uid; call.micOn=true; call.camOn=kind==='video';
  call.calls=[]; call.remoteStreams.clear();
  showCallUI(kind, activeChat.displayName||'User', activeChat.photoURL, 'Memanggil...');

  try{
    call.stream=await getMedia(kind);
    if(kind==='video') $('call-local').srcObject=call.stream;
  }catch(err){
    call.active=false; $('call-screen').classList.remove('show');
    toast('Tidak bisa mengakses '+(kind==='video'?'kamera/mikrofon':'mikrofon')+': '+err.message,'err');
    return;
  }

  const ref=db.ref('calls').push();
  call.id=ref.key;
  const data={
    type:kind, scope:'private',
    callerId:currentUser.uid,
    callerName:currentUser.displayName||(currentUser.email||'').split('@')[0],
    callerPhoto:myPhoto()||'',
    targetUid:call.target,
    status:'ringing',
    createdAtMs:now(),
    participants:{[currentUser.uid]:{peerId:myPeerId,name:currentUser.displayName||'',photo:myPhoto()||'',joinedAt:now()}}
  };
  try{ await ref.set(data); }catch(e){}
  startTimer(); watchCallDoc(ref);

  /* Kirim push FCM supaya panggilan tetap sampai walau penerima
     offline / aplikasi belum dibuka. Kalau gagal, panggilan tetap
     berjalan lewat jalur Realtime Database seperti sebelumnya. */
  call._pushed = false;
  pushIncomingCall(call.target, call.id, kind, data.callerName, data.callerPhoto)
    .then(ok=>{ call._pushed = !!ok; })
    .catch(()=>{});

  /* Catat riwayat panggilan keluar. */
  call._logId = null;
  logCall({
    direction:'out', kind:kind, peerUid:call.target,
    peerName:activeChat.displayName||'User', peerPhoto:activeChat.photoURL||'',
    missed:false, seen:true, durationMs:0
  });

  clearTimeout(callTimeout);
  callTimeout=setTimeout(()=>{
    if(call.active&&call.isCaller&&call.participants<=1){
      /* Tidak ada yang menjawab: tandai tak terjawab + beri tahu penerima. */
      ref.update({status:'missed', missedAt:now()}).catch(()=>{});
      pushCallCancelled(call.target, call.id).catch(()=>{});
      markLastOutgoingMissed();
      ref.remove().catch(()=>{});
      endCall(true);
    }
  },40000);
}

/* Tandai entri riwayat panggilan keluar terakhir sebagai tak terjawab. */
function markLastOutgoingMissed(){
  if(!currentUser) return;
  const p = callLogPath();
  if(!p) return;
  const ref = db.ref(p).push();
  ref.set({
    atMs: now(), direction:'out', kind: call.kind || 'voice',
    peerUid: call.target || '', peerName: (activeChat && activeChat.displayName) || 'User',
    peerPhoto: (activeChat && activeChat.photoURL) || '',
    missed:true, seen:true, durationMs:0
  }).catch(()=>{});
}
function watchCallDoc(ref){
  if(callRef&&callHandler){ callRef.off('value',callHandler); }
  callRef=ref;
  callHandler=ref.on('value',snap=>{
    if(!snap.exists()){ if(call.active) endCall(true); return; }
    const d=snap.val()||{};
    if(d.status==='ended'){ endCall(true); return; }
    /* POINT 3: penerima sudah klik "Terima" -> matikan nada dering /
       suara tut... di perangkat PENELEPON juga, supaya tidak bercampur
       dengan suara obrolan. */
    if(d.status==='accepted' && call.isCaller && !call._ringStopped){
      call._ringStopped=true;
      stopRing();
      try{ if(window.AndroidBridge && window.AndroidBridge.notifyCallAnswered) window.AndroidBridge.notifyCallAnswered(); }catch(e){}
    }
    const parts=d.participants||{};
    const ids=Object.keys(parts);
    call.participants=ids.length;
    if($('call-participants')) $('call-participants').style.display='none';
    if(call.isCaller){
      ids.forEach(uid=>{
        if(uid===currentUser.uid) return;
        const p=parts[uid];
        if(!p||!p.peerId) return;
        if(call.calls.some(c=>c.peer===p.peerId)) return;
        call._callingPeer=p.peerId;
        dialPeer(p.peerId);
      });
    }
  });
}
function listenIncomingCalls(){
  if(callsQuery&&callsQueryHandler){ callsQuery.off('value',callsQueryHandler); }
  callsQuery=db.ref('calls').orderByChild('status').equalTo('ringing');
  callsQueryHandler=callsQuery.on('value',snap=>{
    if(!currentUser) return;
    const t=now();
    snap.forEach(ch=>{
      const d=ch.val()||{};
      if(d.callerId===currentUser.uid) return;
      if(d.createdAtMs&&t-d.createdAtMs>90*1000) return;
      if(declinedCalls.has(ch.key)) return;
      if(call.active) return;
      if(pendingIncoming&&pendingIncoming.id) return;
      if(d.scope!=='private') return;
      if(d.targetUid!==currentUser.uid) return;
      if(d.participants&&d.participants[currentUser.uid]) return;
      const existing=pendingIncoming&&pendingIncoming.mediaConn;
      pendingIncoming={id:ch.key, data:d};
      if(existing) pendingIncoming.mediaConn=existing;
      showIncoming(ch.key,d);
      clearTimeout(incomingTimeout);
      incomingTimeout=setTimeout(()=>{
        if(pendingIncoming&&pendingIncoming.id===ch.key){
          const pid=pendingIncoming.id;
          markIncomingMissed(pid, d);
          hideIncoming(); declinedCalls.add(pid);
          db.ref('calls/'+pid).remove().catch(()=>{});
        }
      },40000);
    });
  }, err=>{});
}
/* Tandai panggilan masuk yang tidak dijawab sebagai "tak terjawab". */
function markIncomingMissed(id, d){
  if(!currentUser) return;
  const p = callLogPath();
  if(!p) return;
  const ref = db.ref(p).push();
  ref.set({
    atMs: now(), direction:'in', kind:(d&&d.type)||'voice',
    peerUid:(d&&d.callerId)||'', peerName:(d&&d.callerName)||'Seseorang',
    peerPhoto:(d&&d.callerPhoto)||'', missed:true, seen:false, durationMs:0
  }).catch(()=>{});
}

function showIncoming(id,d){
  /* Catat panggilan masuk di riwayat penerima. */
  if(d && d.callerId && d.callerId!==(currentUser&&currentUser.uid)){
    logCall({
      direction:'in', kind:d.type||'voice', peerUid:d.callerId,
      peerName:d.callerName||'Seseorang', peerPhoto:d.callerPhoto||'',
      missed:false, seen:true, durationMs:0
    });
  }
  $('in-kind-text').textContent=d.type==='video'?'Panggilan video masuk':'Panggilan suara masuk';
  $('in-name').textContent=d.callerName||'Seseorang';
  /* POINT 4: status khas Smart Live Chat. */
  $('in-status').textContent='Smart Live Chat \u2022 Memanggil...';
  const av=$('in-avatar');
  av.innerHTML=d.callerPhoto?`<img src="${esc(d.callerPhoto)}" alt="">`:esc(initials(d.callerName));
  $('incoming-screen').classList.add('show');
  startRing();
  if(navigator.vibrate) try{ navigator.vibrate([400,200,400]); }catch(e){}
  /* POINT 2: minta native membuka layar panggilan PENUH (bukan hanya
     notifikasi), termasuk saat aplikasi tertutup atau HP terkunci.
     fullScreen:true -> native memakai full-screen intent + CallActivity. */
  bridge({type:'call', payload:JSON.stringify({id:id, type:d.type, callerName:d.callerName, callerPhoto:d.callerPhoto, fullScreen:true})});
}
function hideIncoming(){
  $('incoming-screen').classList.remove('show');
  stopRing(); clearTimeout(incomingTimeout); incomingTimeout=null; pendingIncoming=null;
  bridge({type:'endcall'});
}
async function joinCall(id,d,savedMediaConn){
  /* POINT 3: begitu "Terima" diklik, matikan nada dering / suara tut...
     di perangkat ini, dan beri tahu native supaya nada dering di
     perangkat penelepon juga berhenti. Tidak boleh bercampur dengan
     suara obrolan. */
  stopRing();
  try{ if(window.AndroidBridge && window.AndroidBridge.notifyCallAnswered) window.AndroidBridge.notifyCallAnswered(); }catch(e){}
  const readyId=await ensurePeerReady(12000);
  if(!readyId){ toast('Koneksi panggilan belum siap.','err'); return; }
  call.active=true; call.kind=d.type; call.isCaller=false;
  call.id=id; call.scope=d.scope; call.micOn=true; call.camOn=d.type==='video';
  call.calls=[]; call.remoteStreams.clear();
  showCallUI(d.type, d.callerName||'Panggilan', d.callerPhoto, 'Menyambungkan...');
  try{
    call.stream=await getMedia(d.type);
    if(d.type==='video') $('call-local').srcObject=call.stream;
  }catch(err){
    call.active=false; $('call-screen').classList.remove('show');
    toast('Tidak bisa mengakses perangkat: '+err.message,'err'); return;
  }
  const ref=db.ref('calls/'+id);
  try{
    await ref.update({
      ['participants/'+currentUser.uid]:{peerId:myPeerId,name:currentUser.displayName||'',photo:myPhoto()||'',joinedAt:now()},
      status:'accepted'
    });
  }catch(e){}
  const mc=savedMediaConn||(pendingIncoming&&pendingIncoming.mediaConn);
  if(mc){ try{ mc.answer(call.stream); attachRemote(mc); }catch(e){} }
  pendingIncoming=null;
  startTimer(); watchCallDoc(ref);
}
function endCall(remote){
  if(callRef&&callHandler){ callRef.off('value',callHandler); callRef=null; callHandler=null; }
  if(call.id&&!remote){
    const ref=db.ref('calls/'+call.id);
    if(call.isCaller&&call.participants<=1){
      ref.remove().catch(()=>{});
      /* Penelepon membatalkan sebelum dijawab -> tutup layar panggilan
         masuk di perangkat penerima. */
      if(call.target) pushCallCancelled(call.target, call.id).catch(()=>{});
    }
    else ref.update({status:'ended', endedAt:now()}).catch(()=>{});
  }
  /* Catat durasi panggilan yang benar-benar tersambung. */
  if(call.isCaller && call.startedAt && call.participants>1 && call.target){
    logCall({
      direction:'out', kind:call.kind, peerUid:call.target,
      peerName:(activeChat&&activeChat.displayName)||'User',
      peerPhoto:(activeChat&&activeChat.photoURL)||'',
      missed:false, seen:true, durationMs: now()-call.startedAt
    });
  }
  call.calls.forEach(c=>{ try{ c.close(); }catch(e){} });
  if(call.stream) call.stream.getTracks().forEach(t=>t.stop());
  clearInterval(call.timer); clearTimeout(callTimeout); callTimeout=null;
  clearTimeout(incomingTimeout); incomingTimeout=null;
  $('call-remote').srcObject=null; $('call-local').srcObject=null;
  $('call-screen').classList.remove('show');
  $('call-remote').classList.remove('on'); $('call-local').classList.remove('on');
  $('call-voice').classList.remove('hide'); setVoiceState('waiting');
  call={active:false,id:null,kind:'voice',stream:null,calls:[],remoteStreams:new Map(),
    micOn:true,camOn:true,facing:'user',startedAt:0,timer:null,isCaller:false,target:null,participants:0};
  if(remote) toast('Panggilan berakhir');
}
function stopVoice(){ if(currentAudio){ try{ currentAudio.pause(); }catch(e){} currentAudio=null; currentWrap=null; } }

/* native hooks */
window.__slcIncomingCall=function(payload){
  try{
    const d=typeof payload==='string'?JSON.parse(payload):payload;
    if(!d||!d.id) return;
    if(call.active) return;
    if(pendingIncoming&&pendingIncoming.id) return;
    if(declinedCalls.has(d.id)) return;
    pendingIncoming={id:d.id, data:d};
    showIncoming(d.id,d);
  }catch(e){}
};
window.__slcCallCancelled=function(id){ try{ if(pendingIncoming&&(!id||pendingIncoming.id===id)) hideIncoming(); }catch(e){} };
/* Dipanggil native saat data-message "call_cancel" diterima. */
window.__slcCallCancelledPush=function(payload){
  try{
    const d=typeof payload==='string'?JSON.parse(payload):payload;
    if(!d) return;
    if(pendingIncoming&&(!d.callId||pendingIncoming.id===d.callId)) hideIncoming();
  }catch(e){}
};
window.__slcAcceptCall=function(payload){
  try{
    const d=typeof payload==='string'?JSON.parse(payload):payload;
    if(!d||!d.id) return;
    const p=pendingIncoming;
    if(!p) return;
    const mc=p.mediaConn;
    hideIncoming();
    /* Beri tahu service native bahwa panggilan dijawab, supaya
       foreground service boleh memakai mikrofon/kamera. */
    try{ if(window.AndroidBridge && window.AndroidBridge.notifyCallAnswered) window.AndroidBridge.notifyCallAnswered(); }catch(e){}
    joinCall(p.id, p.data, mc);
  }catch(e){}
};
window.__slcDeclineCall=function(payload){
  try{
    const d=typeof payload==='string'?JSON.parse(payload):payload;
    const p=pendingIncoming;
    /* POINT 3: matikan dering + hapus sinyal panggilan di database. */
    stopRing();
    hideIncoming();
    if(p){ declinedCalls.add(p.id); db.ref('calls/'+p.id).remove().catch(()=>{}); }
  }catch(e){}
};

/* ============================================================
   JAWAB / TOLAK PANGGILAN BERDASARKAN call_id (dari CallActivity)
   ------------------------------------------------------------
   CallActivity adalah proses/WebView TERPISAH dari MainActivity, jadi
   state `pendingIncoming` di sini belum tentu ada. Fungsi di bawah
   mengambil data panggilan langsung dari Realtime Database memakai
   call_id, lalu menyambung ke room. Inilah jalur yang dipakai tombol
   "Terima" di layar panggilan native.
   ============================================================ */
window.__slcAcceptCallById=async function(callId){
  try{
    if(!callId) return false;
    if(call.active) return true;
    /* 1) Kalau panggilan ini sudah tampil di layar masuk, pakai state itu. */
    if(pendingIncoming && pendingIncoming.id===callId){
      const p=pendingIncoming, mc=p.mediaConn;
      hideIncoming();
      try{ if(window.AndroidBridge && window.AndroidBridge.notifyCallAnswered) window.AndroidBridge.notifyCallAnswered(); }catch(e){}
      await joinCall(p.id, p.data, mc);
      return true;
    }
    /* 2) Ambil dari database (app baru dibuka / WebView baru). */
    const snap=await db.ref('calls/'+callId).once('value');
    const d=snap.val();
    if(!d){ toast('Panggilan sudah berakhir','err'); return false; }
    if(d.status==='ended'||d.status==='missed'){ toast('Panggilan sudah berakhir','err'); return false; }
    if(d.targetUid && currentUser && d.targetUid!==currentUser.uid) return false;
    declinedCalls.delete(callId);
    pendingIncoming={id:callId, data:d};
    hideIncoming();
    try{ if(window.AndroidBridge && window.AndroidBridge.notifyCallAnswered) window.AndroidBridge.notifyCallAnswered(); }catch(e){}
    await joinCall(callId, d, null);
    return true;
  }catch(e){ console.warn('__slcAcceptCallById gagal', e); return false; }
};
window.__slcDeclineCallById=function(callId){
  try{
    /* POINT 3: tolak -> matikan dering dan HAPUS sinyal panggilan dari
       database supaya tidak nyangkut sebagai "ringing". */
    stopRing();
    if(pendingIncoming && (!callId || pendingIncoming.id===callId)) hideIncoming();
    if(callId){
      declinedCalls.add(callId);
      db.ref('calls/'+callId).remove().catch(()=>{});
    }
  }catch(e){}
};
/* Dipanggil native setelah izin kamera/mikrofon diberikan, untuk
   melanjutkan panggilan yang sempat tertunda karena izin. */
window.__slcPermissionsGranted=function(){
  try{
    if(window.__slcPendingAcceptId){
      const id=window.__slcPendingAcceptId; window.__slcPendingAcceptId=null;
      window.__slcAcceptCallById(id);
    }
  }catch(e){}
};
/* Token FCM dari native. Disimpan ke users/{uid}/fcmToken (kompatibel
   dengan versi lama) DAN ke users/{uid}/fcmTokens/<token> supaya
   multi-perangkat jalan. Diberi retry karena aturan database bisa
   menolak tulisan pertama saat sesi baru saja dibuat. */
let _lastFcmToken = '';
async function saveFcmToken(tok, attempt){
  if(!tok) return false;
  if(!currentUser){
    /* Belum login: simpan dulu, kirim lagi setelah login. */
    _lastFcmToken = tok;
    return false;
  }
  const uid = currentUser.uid;
  try{
    const upd = {};
    upd['users/' + uid + '/fcmToken'] = tok;
    upd['users/' + uid + '/fcmTokens/' + tok] = true;
    upd['users/' + uid + '/fcmTokenAt'] = now();
    await db.ref().update(upd);
    _lastFcmToken = tok;
    try{ if(window.AndroidBridge && window.AndroidBridge.ackFcmToken) window.AndroidBridge.ackFcmToken(uid); }catch(e){}
    console.log('FCM token tersimpan untuk', uid);
    return true;
  }catch(e){
    const n = attempt || 0;
    if(n < 5){
      setTimeout(()=>{ saveFcmToken(tok, n + 1); }, 1500 * (n + 1));
    } else {
      console.warn('FCM token gagal disimpan:', e && e.message);
    }
    return false;
  }
}
window.__slcFcmToken=function(tok){
  if(!tok) return;
  saveFcmToken(tok, 0);
};
/* Dipanggil saat app kembali ke depan: pastikan token masih ada dan
   masih tersimpan (mis. setelah token dirotasi saat app tertutup). */
function syncFcmToken(){
  if(!isNative() || !window.AndroidBridge) return;
  try{
    if(window.AndroidBridge.getSavedFcmToken){
      const t = window.AndroidBridge.getSavedFcmToken();
      if(t && t.length > 10) saveFcmToken(t, 0);
    }
    if(window.AndroidBridge.refreshFcmToken) window.AndroidBridge.refreshFcmToken();
  }catch(e){}
}
/* Diagnostik FCM: bisa dipanggil dari console atau dipakai UI. */
window.__slcFcmDiag=function(){
  const out = { native:isNative(), uid: currentUser ? currentUser.uid : null, token:null, pending:null, fsi:null };
  try{
    if(window.AndroidBridge && window.AndroidBridge.fcmDiagnostics){
      const d = JSON.parse(window.AndroidBridge.fcmDiagnostics());
      out.token = d.token || '';
      out.pending = d.pending;
      out.fsi = d.fsi;
    }
  }catch(e){}
  console.log('FCM diag', out);
  return out;
};
/* Log native (tersimpan di disk, jadi isinya tetap ada walau app sempat
   ditutup). Ini satu-satunya cara melihat apa yang terjadi pada jalur
   FCM saat app killed: apakah push diterima, apakah notifikasi terpasang,
   dan apakah foreground service berhasil start. */
window.__slcCallLog=function(){
  try{
    if(window.AndroidBridge && window.AndroidBridge.callLog){
      const s = window.AndroidBridge.callLog();
      console.log('=== SLC call log ===\n' + s);
      return s;
    }
  }catch(e){}
  return '(tidak tersedia)';
};
window.__slcClearCallLog=function(){
  try{ if(window.AndroidBridge && window.AndroidBridge.clearCallLog) window.AndroidBridge.clearCallLog(); }catch(e){}
};
/* Uji layar panggilan tanpa perlu ada penelepon. */
window.__slcTestCall=function(){
  try{ if(window.AndroidBridge && window.AndroidBridge.testCallScreen){ window.AndroidBridge.testCallScreen(); return true; } }catch(e){}
  return false;
};
/* Android 14 mewajibkan izin "full-screen notifications" agar layar
   panggilan muncul saat HP terkunci. Tanpa izin itu sistem hanya
   menampilkan banner. Tawarkan sekali untuk membukanya. */
function ensureFullScreenIntent(){
  if(!isNative() || !window.AndroidBridge || !window.AndroidBridge.canUseFullScreenIntent) return;
  try{
    if(window.AndroidBridge.canUseFullScreenIntent()) return;
    if(localStorage.getItem('slc_fsi_asked')) return;
    localStorage.setItem('slc_fsi_asked','1');
    setTimeout(()=>{
      try{
        toast('Aktifkan "Layar penuh" untuk panggilan masuk agar muncul saat HP terkunci','err');
        if(window.AndroidBridge.openFullScreenIntentSettings) window.AndroidBridge.openFullScreenIntentSettings();
      }catch(e){}
    }, 4000);
  }catch(e){}
}
function pushIdentity(){
  if(!currentUser) return;
  bridge({type:'identity', uid:currentUser.uid, name:currentUser.displayName||'', photo:myPhoto()||''});
  try{ if(window.AndroidBridge&&window.AndroidBridge.getFcmToken) window.AndroidBridge.getFcmToken(); }catch(e){}
  /* Pastikan token FCM benar-benar tersimpan setiap kali login. */
  syncFcmToken();
  if(_lastFcmToken) saveFcmToken(_lastFcmToken, 0);
  /* PATCH: paksa refresh token FCM setiap kali login ulang. Token bisa
     dirotasi saat app tertutup; tanpa ini server masih memakai token lama
     sehingga push panggilan tidak sampai. refreshFcmToken() -> native
     getToken() -> deliverFcmToken() -> __slcFcmToken() -> saveFcmToken(). */
  try{ if(window.AndroidBridge && window.AndroidBridge.refreshFcmToken) window.AndroidBridge.refreshFcmToken(); }catch(e){}
  try{
    if(window.AndroidBridge && window.AndroidBridge.getSavedFcmToken){
      const _t = window.AndroidBridge.getSavedFcmToken();
      if(_t && _t.length > 10) saveFcmToken(_t, 0);
    }
  }catch(e){}
  ensureFullScreenIntent();
  /* Minta pengecualian battery optimization sekali saja, supaya panggilan
     masuk tetap sampai walau aplikasi ditutup / HP terkunci. */
  try{
    if(window.AndroidBridge && window.AndroidBridge.requestBatteryExemption
       && !localStorage.getItem('slc_batt_asked')){
      localStorage.setItem('slc_batt_asked','1');
      setTimeout(()=>{ try{ window.AndroidBridge.requestBatteryExemption(); }catch(e){} }, 2500);
    }
  }catch(e){}
}

/* ---------------- users ---------------- */
function loadUsers(){
  if(usersRef){ usersRef.off('value'); usersRef=null; }
  usersRef=db.ref('users').limitToLast(300);
  usersRef.on('value',snap=>{
    usersCache=[];
    snap.forEach(ch=>{
      const u=ch.val()||{};
      u.uid=ch.key;
      if(u.deleted===true||u.hidden===true) return;
      if(u.status==='deleted'||u.status==='banned') return;
      if(u.active===false||u.canChat===false) return;
      usersCache.push(u);
    });
    usersCache.sort((a,b)=>(a.displayName||'').localeCompare(b.displayName||''));
    renderList();
    if(activeChat.type==='group') setHeader();
  }, err=>{
    const l=$('chat-list');
    if(l) l.innerHTML=`<div class="empty-list">Gagal memuat pengguna.<br>${esc(err.message)}</div>`;
  });
}

/* ---------------- auth state ---------------- */
/* Simpan uid + token ke native (SharedPreferences) supaya
   PresenceService bisa memantau calls/ walau app ditutup. */
async function syncPresenceSession(user){
  if(!user) return;
  try{
    if(!window.SlcPresence || !window.SlcPresence.saveSession) return;
    let idt='', rt='';
    try{ idt = await user.getIdToken(false); }catch(e){}
    try{ rt = user.refreshToken || ''; }catch(e){}
    window.SlcPresence.saveSession(user.uid, idt||'', rt||'');
    console.log('Sesi disimpan ke PresenceService');
  }catch(e){ console.warn('syncPresenceSession:', e); }
}
window.__slcSyncPresence=function(){ try{ if(currentUser) syncPresenceSession(currentUser); }catch(e){} };

if (auth) {
auth.onAuthStateChanged(async (user)=>{
  /* POINT 1: sesi Firebase sudah dipulihkan (dari cache lokal).
     Sembunyikan splash auth. Form Login Google TIDAK pernah tampil
     di sini selama sesi tersimpan masih ada. */
  try{ $('auth-splash').classList.add('hide'); }catch(e){}
  if(user){
    currentUser=user;
    $('login-screen').classList.add('hide');
    $('composer').classList.remove('disabled');
    const name=user.displayName||(user.email||'').split('@')[0];
    $('me-name').textContent=name;
    $('me-status-text').textContent='Online';
    $('me-dot').className='dot';
    refreshMyAvatar();
    await saveUserProfile(user);
    try{ await db.ref('users/'+user.uid).update({online:true, lastSeen:now()}); }catch(e){}
    initPeer(); pushIdentity(); listenIncomingCalls(); loadUsers();
    setHeader(); loadMessages(); syncProfileUI();
    loadCallLog();
    /* CADANGAN: kalau FCM tidak sampai (app killed / push diblokir),
       deteksi panggilan yang masih "ringing" di Realtime Database
       begitu aplikasi dibuka kembali. */
    setTimeout(()=>{ try{ resumeCallCheck(); }catch(e){} }, 1200);
    setTimeout(()=>{ try{ notifyMissedCalls(); }catch(e){} }, 2500);
    /* Minta izin runtime (mikrofon, kamera, notifikasi) sekali saat masuk,
       supaya panggilan pertama tidak gagal karena izin belum diberikan. */
    try{ if(window.AndroidBridge&&window.AndroidBridge.requestPermissions) window.AndroidBridge.requestPermissions(); }catch(e){}
    if(window.__slcPendingCall){ try{ window.__slcIncomingCall(window.__slcPendingCall); }catch(e){} }
  } else {
    currentUser=null;
    try{ if(window.SlcPresence && window.SlcPresence.clearSession) window.SlcPresence.clearSession(); }catch(e){}
    $('login-screen').classList.remove('hide');
    $('composer').classList.add('disabled');
    $('me-name').textContent='Belum masuk';
    $('me-status-text').textContent='Offline';
    $('me-dot').className='dot off';
    $('me-avatar').textContent='?';
    if(msgRef&&msgHandler){ msgRef.off('value',msgHandler); msgRef=null; }
    if(callsQuery&&callsQueryHandler){ callsQuery.off('value',callsQueryHandler); callsQuery=null; }
    if(peer){ try{ peer.destroy(); }catch(e){} peer=null; myPeerId=null; }
  }
});
} else {
  /* Firebase tidak bisa diinisialisasi: tetap tampilkan layar login dengan
     penjelasan, jangan biarkan aplikasi kosong/putih. */
  document.addEventListener('DOMContentLoaded',()=>{
    try{ $('auth-splash').classList.add('hide'); }catch(e){}
    try{ $('login-screen').classList.remove('hide'); }catch(e){}
    showAuthError('Layanan chat belum siap: '+(window.__SLC_FIREBASE_ERROR__||'konfigurasi Firebase tidak valid')+'. Periksa koneksi internet lalu buka ulang aplikasi.');
  });
}

/* ---------------- wiring ---------------- */
/* ---------------- panel diagnostik ---------------- */
function diagRow(label, ok, detail){
  const color = ok ? '#16a34a' : '#dc2626';
  const mark = ok ? '&#10003;' : '&#10007;';
  return '<div style="display:flex;gap:10px;align-items:flex-start;padding:8px 0;border-bottom:1px solid rgba(0,0,0,.07)">'
    + '<div style="color:'+color+';font-weight:700;min-width:16px">'+mark+'</div>'
    + '<div style="flex:1"><div style="font-weight:600;font-size:13px">'+label+'</div>'
    + '<div style="font-size:11px;opacity:.7;word-break:break-all">'+(detail||'')+'</div></div></div>';
}
function renderDiag(){
  const box = $('diag-list');
  if(!box) return;
  let d = null;
  try{ if(window.SlcPresence && window.SlcPresence.diagnostics) d = JSON.parse(window.SlcPresence.diagnostics()); }catch(e){}
  if(!d){
    box.innerHTML = diagRow('Mode native', false, 'Jembatan native tidak tersedia (mungkin dibuka di browser).');
    return;
  }
  let html = '';
  html += diagRow('Login tersimpan', !!d.uid, d.uid ? ('uid: '+d.uid) : 'Belum login');
  html += diagRow('Token akses', !!d.hasIdToken, d.hasIdToken ? 'Ada' : 'Tidak ada — login ulang');
  html += diagRow('Token refresh', !!d.hasRefreshToken, d.hasRefreshToken ? 'Ada' : 'Tidak ada — service tidak bisa memperbarui sesi');
  html += diagRow('Service latar (fallback)', !!d.presenceRunning, d.presenceRunning ? 'Berjalan — panggilan terdeteksi walau app ditutup' : 'Mati — buka app sekali untuk menghidupkan');
  html += diagRow('Izin notifikasi', !!d.notifPermission, d.notifPermission ? 'Diizinkan' : 'DITOLAK — notifikasi tidak akan muncul');
  html += diagRow('Full-screen intent', !!d.fullScreenIntent, d.fullScreenIntent ? 'Diizinkan' : 'DIBATASI — layar panggilan tidak muncul di lockscreen');
  html += diagRow('Battery optimization', !!d.batteryUnrestricted, d.batteryUnrestricted ? 'Tanpa batas' : 'DIBATASI — service bisa dimatikan sistem');
  html += diagRow('Token FCM', !!(d.fcmToken && d.fcmToken.length>10), d.fcmToken ? d.fcmToken.substring(0,28)+'...' : 'Belum ada');
  html += diagRow('Android SDK', true, 'API '+d.sdk);
  box.innerHTML = html;
}
window.__slcRenderDiag = renderDiag;

function wireAll(){
  // settings
  document.addEventListener('click',function(e){
    const t=e.target; if(!t||!t.closest) return;
    if(t.closest('#btn-diag-refresh')){ e.preventDefault(); renderDiag(); return; }
    if(t.closest('#btn-diag-notif')){ e.preventDefault(); try{ if(window.SlcPresence&&window.SlcPresence.openNotificationSettings) window.SlcPresence.openNotificationSettings(); }catch(x){} return; }
    if(t.closest('#btn-diag-batt')){ e.preventDefault(); try{ if(window.SlcPresence&&window.SlcPresence.openBatterySettings) window.SlcPresence.openBatterySettings(); }catch(x){} return; }
    if(t.closest('#btn-diag-test')){ e.preventDefault(); try{ if(window.AndroidBridge&&window.AndroidBridge.testCallScreen) window.AndroidBridge.testCallScreen(); }catch(x){} return; }
    if(t.closest('#btn-settings')||t.closest('#btn-sound-foot')){ e.preventDefault(); openSettings(); return; }
    if(t.closest('#btn-close-settings')){ e.preventDefault(); closeSettings(); return; }
    if(t.id==='settings-overlay'){ closeSettings(); return; }
    if(t.closest('#sw-enabled')){ soundCfg.enabled=!soundCfg.enabled; saveSound(); syncSettingsUI(); if(soundCfg.enabled){ primeAudio(); playTone(soundCfg.tone,soundCfg.volume); } return; }
    if(t.closest('#sw-send')){ soundCfg.sendSound=!soundCfg.sendSound; saveSound(); syncSettingsUI(); return; }
    if(t.closest('#btn-test-sound')){ e.preventDefault(); primeAudio(); if(!soundCfg.enabled){ soundCfg.enabled=true; saveSound(); syncSettingsUI(); } playTone(soundCfg.tone,soundCfg.volume); setTimeout(updateAudioStatus,120); toast('Memutar nada '+(TONES[soundCfg.tone]||TONES.chime).label,'ok'); return; }
  },true);

  document.querySelectorAll('.set-tab').forEach(tab=>tab.addEventListener('click',()=>{
    document.querySelectorAll('.set-tab').forEach(t=>t.classList.remove('active'));
    document.querySelectorAll('.set-pane').forEach(p=>p.classList.remove('active'));
    tab.classList.add('active');
    const pane=document.querySelector('.set-pane[data-pane="'+tab.dataset.pane+'"]');
    if(pane) pane.classList.add('active');
    if(tab.dataset.pane==='profile') syncProfileUI();
    if(tab.dataset.pane==='theme') renderThemes();
    if(tab.dataset.pane==='diag') renderDiag();
  }));

  $('vol-range').addEventListener('input',e=>{
    soundCfg.volume=Number(e.target.value)/100;
    $('vol-label').textContent=e.target.value+'%'; saveSound();
  });
  $('vol-range').addEventListener('change',()=>{ primeAudio(); playTone(soundCfg.tone,soundCfg.volume); });

  // auth
  $('btn-google-login').addEventListener('click',e=>{ e.preventDefault(); startGoogleLogin(); });
  $('btn-email-toggle').addEventListener('click',()=>$('email-form').classList.toggle('on'));
  $('btn-email-login').addEventListener('click',()=>emailAuth(false));
  $('btn-email-register').addEventListener('click',()=>emailAuth(true));

  // logout
  $('btn-logout').addEventListener('click',()=>{
    if(!confirm('Keluar dari akun ini?')) return;
    if(msgRef&&msgHandler) msgRef.off('value',msgHandler);
    if(callsQuery&&callsQueryHandler) callsQuery.off('value',callsQueryHandler);
    if(peer){ try{ peer.destroy(); }catch(e){} }
    if(currentUser) db.ref('users/'+currentUser.uid).update({online:false,lastSeen:now()}).catch(()=>{});
    auth.signOut().then(()=>{ try{ if(window.AndroidBridge&&window.AndroidBridge.googleSignOut) window.AndroidBridge.googleSignOut(); }catch(e){} location.reload(); });
  });

  // search + tabs
  $('search-input').addEventListener('input',e=>{ searchTerm=e.target.value.trim(); renderList(); });
  document.querySelectorAll('.tab').forEach(t=>t.addEventListener('click',()=>{
    document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));
    t.classList.add('active'); activeTab=t.dataset.tab; renderList();
  }));

  // back
  $('btn-back').addEventListener('click',()=>{
    try{ stopVoice(); }catch(e){}
    $('app').classList.remove('chat-open'); renderList();
  });

  // lightbox
  $('lightbox').addEventListener('click',()=>$('lightbox').classList.remove('show'));

  // profile photo
  $('btn-pick-photo').addEventListener('click',()=>{ if(!currentUser){ toast('Masuk dulu','err'); return; } $('photo-input').click(); });
  $('photo-input').addEventListener('change', async function(){
    const file=this.files[0]; this.value='';
    if(!file||!currentUser) return;
    if(!file.type.startsWith('image/')){ toast('Pilih file gambar','err'); return; }
    if(file.size>5*1024*1024){ toast('Ukuran foto maksimal 5MB','err'); return; }
    const hint=$('photo-hint'); hint.textContent='Memproses foto...';
    let dataUrl='';
    try{ dataUrl=await compressImage(file,320,0.85); }catch(e){ toast('Gagal membaca gambar','err'); return; }
    localPhoto=dataUrl;
    try{ localStorage.setItem(PHOTO_KEY,dataUrl); }catch(e){}
    syncProfileUI(); refreshMyAvatar();
    hint.textContent='Mengunggah ke server...';
    try{
      const ref=storage.ref('avatars/'+currentUser.uid+'_'+Date.now()+'.jpg');
      const snap=await ref.putString(dataUrl,'data_url');
      const url=await snap.ref.getDownloadURL();
      await db.ref('users/'+currentUser.uid).update({photoURL:url});
      localPhoto=url; try{ localStorage.setItem(PHOTO_KEY,url); }catch(e){}
      syncProfileUI(); refreshMyAvatar();
      hint.textContent='Foto profil diperbarui dan tersinkron.';
      toast('Foto profil diperbarui','ok');
    }catch(err){
      hint.textContent='Foto tersimpan di perangkat. Sinkron gagal: '+err.message;
      toast('Foto tersimpan lokal','err');
    }
  });
  $('btn-reset-photo').addEventListener('click',async ()=>{
    if(!currentUser) return;
    localPhoto=''; try{ localStorage.removeItem(PHOTO_KEY); }catch(e){}
    syncProfileUI(); refreshMyAvatar();
    try{ await db.ref('users/'+currentUser.uid).update({photoURL:''}); toast('Foto profil direset','ok'); }
    catch(e){ toast('Direset di perangkat','ok'); }
  });

  // download APK
  const dl=$('btn-download-apk');
  if(dl){
    dl.setAttribute('href',APK_URL);
    dl.addEventListener('click',e=>{
      if(isNative()&&window.AndroidBridge&&window.AndroidBridge.downloadApk){
        e.preventDefault();
        try{ window.AndroidBridge.downloadApk(APK_URL); }catch(err){ window.open(APK_URL,'_blank'); }
      }
    });
  }

  // riwayat panggilan
  const btnLog=$('btn-call-log');
  if(btnLog) btnLog.addEventListener('click',e=>{ e.preventDefault(); openCallLog(); });
  const btnLogClose=$('btn-close-call-log');
  if(btnLogClose) btnLogClose.addEventListener('click',e=>{ e.preventDefault(); closeCallLog(); });
  const logOv=$('call-log-overlay');
  if(logOv) logOv.addEventListener('click',e=>{ if(e.target===logOv) closeCallLog(); });

  // calls
  $('btn-voice-call').addEventListener('click',()=>startCall('voice'));
  $('btn-video-call').addEventListener('click',()=>startCall('video'));
  $('cc-end').addEventListener('click',()=>endCall(false));
  $('cc-mic').addEventListener('click',()=>{
    if(!call.stream) return;
    call.micOn=!call.micOn;
    call.stream.getAudioTracks().forEach(t=>t.enabled=call.micOn);
    $('cc-mic').classList.toggle('off',!call.micOn);
    if(call.kind!=='video') setVoiceState(call.micOn?'live':'muted');
    $('cc-mic').innerHTML=call.micOn
      ? `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><path d="M12 19v4"/></svg>`
      : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 1l22 22"/><path d="M9 9v3a3 3 0 0 0 5.12 2.12M15 9.34V4a3 3 0 0 0-5.94-.6"/><path d="M17 16.95A7 7 0 0 1 5 12v-2m14 0v2a7 7 0 0 1-.11 1.23"/><path d="M12 19v4"/></svg>`;
  });
  $('cc-cam').addEventListener('click',()=>{
    if(!call.stream) return;
    call.camOn=!call.camOn;
    call.stream.getVideoTracks().forEach(t=>t.enabled=call.camOn);
    $('cc-cam').classList.toggle('off',!call.camOn);
    $('call-local').style.opacity=call.camOn?'1':'.25';
  });
  $('cc-switch').addEventListener('click',async ()=>{
    if(!call.stream||call.kind!=='video') return;
    call.facing=call.facing==='user'?'environment':'user';
    try{
      const ns=await navigator.mediaDevices.getUserMedia({video:{facingMode:call.facing},audio:false});
      const nv=ns.getVideoTracks()[0];
      const old=call.stream.getVideoTracks()[0];
      call.stream.removeTrack(old); old.stop(); call.stream.addTrack(nv);
      $('call-local').srcObject=call.stream;
      call.calls.forEach(c=>{
        const sender=c.peerConnection&&c.peerConnection.getSenders().find(s=>s.track&&s.track.kind==='video');
        if(sender) sender.replaceTrack(nv).catch(()=>{});
      });
    }catch(e){ toast('Gagal ganti kamera','err'); }
  });
  $('in-decline').addEventListener('click',async ()=>{
    const p=pendingIncoming; hideIncoming();
    if(p){ declinedCalls.add(p.id); try{ await db.ref('calls/'+p.id).remove(); }catch(e){} }
  });
  $('in-accept').addEventListener('click',async ()=>{
    const p=pendingIncoming; if(!p) return;
    const mc=p.mediaConn; hideIncoming();
    await joinCall(p.id,p.data,mc);
  });

  wireComposer(); wireAttach(); wireDelete();
}

/* ---------------- init ---------------- */
applyTheme(currentTheme);
renderList(); syncSettingsUI(); syncProfileUI(); setHeader();
wireAll();
document.addEventListener('DOMContentLoaded',()=>{ audioCtx(); updateAudioStatus(); });
window.addEventListener('beforeunload',()=>{ if(call.active) endCall(false); });

function resumeCallCheck(){
  try{
    if(!currentUser||call.active) return;
    if(pendingIncoming&&pendingIncoming.id) return;
    db.ref('calls').orderByChild('status').equalTo('ringing').once('value').then(snap=>{
      const t=now();
      snap.forEach(ch=>{
        const d=ch.val()||{};
        if(d.callerId===currentUser.uid) return;
        if(d.createdAtMs&&t-d.createdAtMs>90*1000) return;
        if(declinedCalls.has(ch.key)) return;
        if(call.active) return;
        if(pendingIncoming&&pendingIncoming.id) return;
        if(d.scope!=='private') return;
        if(d.targetUid!==currentUser.uid) return;
        if(d.participants&&d.participants[currentUser.uid]) return;
        pendingIncoming={id:ch.key,data:d};
        showIncoming(ch.key,d);
      });
    }).catch(()=>{});
  }catch(e){}
}
document.addEventListener('visibilitychange',()=>{ if(document.visibilityState==='visible'){ resumeCallCheck(); notifyMissedCalls(); syncFcmToken(); } });
window.addEventListener('focus',()=>{ resumeCallCheck(); notifyMissedCalls(); syncFcmToken(); });

/* ============================================================
   PARAMETER URL DARI CallActivity
   ------------------------------------------------------------
   CallActivity membuka WebView dengan
     index.html?room_id=<callId>&token=<token>&auto_accept=1
   Sebelumnya parameter ini SAMA SEKALI tidak dibaca, sehingga WebView
   hanya memuat aplikasi biasa dan panggilan tidak pernah tersambung.
   Sekarang: simpan call_id, lalu jawab otomatis setelah user login.
   ============================================================ */
(function readCallParams(){
  try{
    const qs = (location.search||'').replace(/^\?/,'');
    if(!qs) return;
    const params = {};
    qs.split('&').forEach(kv=>{
      const i = kv.indexOf('=');
      if(i < 0) return;
      params[decodeURIComponent(kv.slice(0,i))] = decodeURIComponent(kv.slice(i+1).replace(/\+/g,' '));
    });
    const callId = params.room_id || params.call_id || params.callId;
    if(!callId) return;
    window.__slcPendingCallToken = params.token || '';

    /* POINT 2: CallActivity membuka halaman ini dengan call_screen=1 untuk
       panggilan MASUK. Di mode itu layar panggilan penuh harus langsung
       tampil (Terima/Tolak), BUKAN auto-accept. */
    const isCallScreen = params.call_screen === '1';
    const autoAccept = params.auto_accept === '1';

    if(isCallScreen && !autoAccept){
      const show = ()=>{
        if(!currentUser) return false;
        if(call.active) return true;
        if(pendingIncoming && pendingIncoming.id===callId) return true;
        pendingIncoming={id:callId, data:{
          id:callId,
          type:params.call_type||'voice',
          callerName:params.caller_name||'Seseorang',
          callerPhoto:params.caller_photo||''
        }};
        showIncoming(callId, pendingIncoming.data);
        return true;
      };
      if(!show()){
        const iv=setInterval(()=>{ if(show()) clearInterval(iv); },400);
        setTimeout(()=>clearInterval(iv),60000);
      }
      return;
    }

    window.__slcPendingAcceptId = callId;
    console.log('CallActivity: menunggu jawab panggilan', callId);
    /* Kalau sudah login, langsung jawab. Kalau belum, tunggu auth.onAuthStateChanged. */
    const tryAccept = ()=>{
      if(!currentUser) return false;
      const id = window.__slcPendingAcceptId;
      if(!id) return true;
      window.__slcPendingAcceptId = null;
      window.__slcAcceptCallById(id);
      return true;
    };
    if(!tryAccept()){
      const iv = setInterval(()=>{ if(tryAccept()) clearInterval(iv); }, 500);
      setTimeout(()=>clearInterval(iv), 60000);
    }
  }catch(e){ console.warn('readCallParams gagal', e); }
})();
