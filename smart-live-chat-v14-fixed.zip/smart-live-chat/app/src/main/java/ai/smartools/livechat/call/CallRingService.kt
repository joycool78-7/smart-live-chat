package ai.smartools.livechat.call

import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import ai.smartools.livechat.SlcApp

/**
 * CallRingService — nada dering / suara "tut..." panggilan.
 *
 * POINT 3: begitu panggilan DIANGKAT, dering harus langsung mati di kedua
 * perangkat. Service ini:
 *   - memutar dering lewat STREAM_RING (bukan STREAM_MUSIC) supaya tidak
 *     bercampur dengan suara obrolan;
 *   - berhenti total pada aksi ACTION_STOP (dipanggil saat Terima / Tolak /
 *     panggilan berakhir);
 *   - menghentikan getar juga.
 */
class CallRingService : Service() {

    private var player: MediaPlayer? = null
    private var vibrator: Vibrator? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopEverything(); stopSelf(); return START_NOT_STICKY }
            ACTION_START -> startRing(intent)
        }
        return START_STICKY
    }

    private fun startRing(intent: Intent) {
        // Foreground supaya tidak dibunuh sistem saat HP terkunci.
        try {
            startForeground(
                CallNotifier.NOTIF_ID + 1,
                CallNotifier.serviceNotification(this, "Panggilan masuk…")
            )
        } catch (_: Throwable) { }

        stopEverything()

        val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        try {
            player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                setDataSource(this@CallRingService, uri)
                isLooping = true
                prepare()
                start()
            }
        } catch (_: Throwable) { player = null }

        startVibration()
    }

    private fun startVibration() {
        try {
            vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            val pattern = longArrayOf(0, 700, 500, 700, 500)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(pattern, 0)
            }
        } catch (_: Throwable) { }
    }

    /** POINT 3: matikan dering + getar seketika. */
    private fun stopEverything() {
        try { player?.stop() } catch (_: Throwable) { }
        try { player?.release() } catch (_: Throwable) { }
        player = null
        try { vibrator?.cancel() } catch (_: Throwable) { }
        vibrator = null
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.abandonAudioFocus(null)
        } catch (_: Throwable) { }
    }

    override fun onDestroy() {
        stopEverything()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "ai.smartools.livechat.RING_START"
        const val ACTION_STOP = "ai.smartools.livechat.RING_STOP"

        fun start(ctx: Context) {
            try {
                val i = Intent(ctx, CallRingService::class.java).setAction(ACTION_START)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    ctx.startForegroundService(i) else ctx.startService(i)
            } catch (_: Throwable) { }
        }

        /** Dipanggil saat Terima / Tolak / panggilan berakhir. */
        fun stop(ctx: Context) {
            try {
                val i = Intent(ctx, CallRingService::class.java).setAction(ACTION_STOP)
                ctx.startService(i)
            } catch (_: Throwable) { }
        }
    }
}
