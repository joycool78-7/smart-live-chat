package ai.smartools.livechat

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

/**
 * Smart Live Chat — Application.
 *
 * POINT 1: Firebase Auth memakai penyimpanan lokal (default SDK). Sesi yang
 * sudah pernah login dipulihkan TANPA UI, jadi aplikasi tidak pernah
 * menampilkan Login Google hanya karena dibuka ulang.
 */
class SlcApp : Application() {

    override fun onCreate() {
        super.onCreate()
        FirebaseApp.initializeApp(this)

        // Sesi tersimpan dipakai terus; jangan paksa login ulang.
        FirebaseAuth.getInstance().setPersistenceEnabled(true)

        // Cache offline supaya panggilan masuk tetap terbaca saat sinyal jelek.
        try {
            FirebaseDatabase.getInstance().setPersistenceEnabled(true)
        } catch (_: Throwable) { /* sudah aktif */ }

        createChannels()
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = getSystemService(NotificationManager::class.java) ?: return

        // Kanal panggilan: HIGH + suara, dipakai full-screen intent.
        val call = NotificationChannel(
            CHANNEL_CALLS, "Panggilan masuk", NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Panggilan suara & video Smart Live Chat"
            enableVibration(true)
            setShowBadge(true)
            lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
        }
        nm.createNotificationChannel(call)

        val svc = NotificationChannel(
            CHANNEL_SERVICE, "Layanan panggilan", NotificationManager.IMPORTANCE_LOW
        ).apply { description = "Menjaga panggilan tetap tersambung" }
        nm.createNotificationChannel(svc)
    }

    companion object {
        const val CHANNEL_CALLS = "slc_calls"
        const val CHANNEL_SERVICE = "slc_service"
    }
}
