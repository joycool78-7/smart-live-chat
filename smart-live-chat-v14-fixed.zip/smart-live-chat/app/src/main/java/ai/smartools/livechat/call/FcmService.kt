package ai.smartools.livechat.call

import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/**
 * FcmService — penerima data-message panggilan.
 *
 * POINT 2: saat data-message panggilan masuk, layar panggilan penuh dibuka
 * LANGSUNG (full-screen intent + CallActivity), bukan hanya notifikasi.
 *
 * POINT 3: saat menerima "call_cancel" / "call_answered", dering dimatikan
 * dan sinyal panggilan yang sudah tidak berlaku dihapus dari database.
 */
class FcmService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_TOKEN, token).apply()
    }

    override fun onMessageReceived(msg: RemoteMessage) {
        val d = msg.data
        if (d.isEmpty()) return

        val type = d["type"] ?: ""
        val callId = d["call_id"] ?: d["callId"] ?: d["room_id"] ?: ""
        val callerName = d["callerName"] ?: d["caller_name"] ?: "Seseorang"
        val callerPhoto = d["callerPhoto"] ?: d["caller_photo"] ?: ""
        val kind = d["callType"] ?: d["call_type"] ?: "voice"

        when (type) {
            "call", "incoming_call", "call_incoming" -> {
                if (callId.isBlank()) return
                Log.i(TAG, "panggilan masuk $callId ($kind)")

                // POINT 2: notifikasi + full-screen intent.
                CallNotifier.showIncoming(this, callId, kind, callerName, callerPhoto)

                // POINT 3: dering mulai di service (STREAM_RING).
                CallRingService.start(this)

                // POINT 2: buka layar panggilan penuh segera.
                CallLaunch.launchDirect(this, callId, kind, callerName, callerPhoto)
            }

            "call_cancel", "call_cancelled", "call_end", "call_ended" -> {
                // POINT 3: penelepon membatalkan -> matikan dering, hapus sinyal.
                CallRingService.stop(this)
                CallNotifier.cancel(this)
                if (callId.isNotBlank()) removeCallSignal(callId)
            }

            "call_answered", "call_accepted" -> {
                // POINT 3: sudah diangkat -> dering mati di perangkat ini juga.
                CallRingService.stop(this)
                CallNotifier.cancel(this)
            }
        }
    }

    /**
     * POINT 3: hapus sinyal panggilan di database supaya tidak nyangkut
     * sebagai "ringing" ketika panggilan ditolak / tidak diangkat.
     */
    private fun removeCallSignal(callId: String) {
        try {
            val ref = FirebaseDatabase.getInstance().getReference("calls").child(callId)
            ref.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snap: DataSnapshot) {
                    val status = snap.child("status").getValue(String::class.java)
                    if (status == null || status == "ringing") {
                        ref.removeValue()
                    } else {
                        ref.child("status").setValue("ended")
                    }
                }
                override fun onCancelled(error: DatabaseError) { }
            })
        } catch (_: Throwable) { }
    }

    companion object {
        private const val TAG = "SlcFcm"
        const val PREFS = "slc_native"
        const val KEY_TOKEN = "fcm_token"
    }
}
