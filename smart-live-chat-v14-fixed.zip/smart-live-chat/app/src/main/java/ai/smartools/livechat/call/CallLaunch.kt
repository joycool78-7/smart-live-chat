package ai.smartools.livechat.call

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings

/**
 * CallLaunch — satu tempat untuk membuka layar panggilan.
 *
 * POINT 2: panggilan masuk HARUS langsung tampil layar penuh, bukan hanya
 * notifikasi. Di sini kita:
 *   1. memasang full-screen intent (dipakai sistem saat HP terkunci / app
 *      tertutup) — ini yang membuat layar panggilan muncul sendiri;
 *   2. menyiapkan PendingIntent "Terima" / "Tolak" supaya user bisa
 *      menjawab langsung dari layar kunci tanpa membuka notifikasi;
 *   3. menyediakan fallback startActivity kalau full-screen intent dibatasi
 *      OEM (butuh izin SYSTEM_ALERT_WINDOW / USE_FULL_SCREEN_INTENT).
 */
object CallLaunch {

    const val EXTRA_CALL_ID = "slc_call_id"
    const val EXTRA_CALL_TYPE = "slc_call_type"
    const val EXTRA_CALLER_NAME = "slc_caller_name"
    const val EXTRA_CALLER_PHOTO = "slc_caller_photo"
    const val EXTRA_AUTO_ACCEPT = "slc_auto_accept"

    /** Intent yang membuka CallActivity dalam mode "panggilan masuk". */
    fun incomingIntent(
        ctx: Context,
        callId: String,
        type: String?,
        callerName: String?,
        callerPhoto: String?
    ): Intent = Intent(ctx, CallActivity::class.java).apply {
        action = CallActivity.ACTION_INCOMING
        flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_CLEAR_TOP or
                Intent.FLAG_ACTIVITY_SINGLE_TOP
        putExtra(EXTRA_CALL_ID, callId)
        putExtra(EXTRA_CALL_TYPE, type ?: "voice")
        putExtra(EXTRA_CALLER_NAME, callerName ?: "Seseorang")
        putExtra(EXTRA_CALLER_PHOTO, callerPhoto ?: "")
    }

    /** PendingIntent untuk full-screen intent (wajib immutable di S+). */
    fun fullScreenPendingIntent(
        ctx: Context,
        callId: String,
        type: String?,
        callerName: String?,
        callerPhoto: String?
    ): PendingIntent {
        val i = incomingIntent(ctx, callId, type, callerName, callerPhoto)
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        else PendingIntent.FLAG_UPDATE_CURRENT
        return PendingIntent.getActivity(ctx, callId.hashCode(), i, flags)
    }

    /** PendingIntent tombol "Terima" di notifikasi. */
    fun acceptPendingIntent(ctx: Context, callId: String): PendingIntent {
        val i = Intent(ctx, CallActivity::class.java).apply {
            action = CallActivity.ACTION_ACCEPT
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_CALL_ID, callId)
            putExtra(EXTRA_AUTO_ACCEPT, true)
        }
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        else PendingIntent.FLAG_UPDATE_CURRENT
        return PendingIntent.getActivity(ctx, (callId + "_acc").hashCode(), i, flags)
    }

    /** PendingIntent tombol "Tolak" di notifikasi. */
    fun declinePendingIntent(ctx: Context, callId: String): PendingIntent {
        val i = Intent(ctx, CallActivity::class.java).apply {
            action = CallActivity.ACTION_DECLINE
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_CALL_ID, callId)
        }
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        else PendingIntent.FLAG_UPDATE_CURRENT
        return PendingIntent.getActivity(ctx, (callId + "_dec").hashCode(), i, flags)
    }

    /**
     * POINT 2 fallback: kalau sistem menolak full-screen intent (banyak OEM
     * memblokirnya), buka CallActivity langsung dari service. Butuh izin
     * "tampil di atas aplikasi lain"; kalau belum ada, tetap dicoba dan
     * dibiarkan gagal dengan aman.
     */
    fun launchDirect(ctx: Context, callId: String, type: String?, name: String?, photo: String?) {
        try {
            ctx.startActivity(incomingIntent(ctx, callId, type, name, photo))
        } catch (_: Throwable) { }
    }

    fun canUseFullScreenIntent(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.UPSIDE_DOWN_CAKE) return true
        return try {
            val nm = ctx.getSystemService(android.app.NotificationManager::class.java)
            nm?.canUseFullScreenIntent() ?: false
        } catch (_: Throwable) { false }
    }

    fun openFullScreenIntentSettings(ctx: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.UPSIDE_DOWN_CAKE) return
        try {
            val i = Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT)
                .setData(Uri.parse("package:" + ctx.packageName))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        } catch (_: Throwable) { }
    }
}
