package ai.smartools.livechat.call

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import ai.smartools.livechat.R

/**
 * CallActivity — layar panggilan penuh Smart Live Chat.
 *
 * POINT 2: activity ini dibuka LANGSUNG oleh full-screen intent / FCM,
 * jadi layar panggilan tampil penuh tanpa user harus klik notifikasi dulu.
 * showWhenLocked + turnScreenOn (di manifest) membuatnya muncul di atas
 * lockscreen. Tombol Terima / Tolak ada di layar, bukan di notifikasi.
 *
 * POINT 4: tampilan khas Smart Live Chat (gradient ungu-biru-cyan, logo,
 * indikator LIVE, ring avatar berdenyut, audio wave, tombol neon) ada di
 * www/index.html + app.css. Activity ini hanya host WebView yang memuat
 * layar panggilan tersebut.
 *
 * POINT 3: saat Terima diklik, dering dimatikan seketika (CallRingService
 * STOP) dan sinyal panggilan diperbarui supaya penelepon juga berhenti
 * menelepon. Saat Tolak, sinyal panggilan DIHAPUS dari database.
 */
class CallActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private var callId: String = ""
    private var callType: String = "voice"
    private var callerName: String = "Seseorang"
    private var callerPhoto: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // POINT 2: tampil di atas lockscreen, nyalakan layar, jangan redup.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        try {
            val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) km.requestDismissKeyguard(this, null)
        } catch (_: Throwable) { }

        setContentView(R.layout.activity_call)
        web = findViewById(R.id.call_web)

        readIntent(intent)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.webViewClient = WebViewClient()

        // Layar panggilan memakai halaman yang sama, dengan parameter call_id.
        val url = "file:///android_asset/www/index.html" +
                "?room_id=" + android.net.Uri.encode(callId) +
                "&call_type=" + android.net.Uri.encode(callType) +
                "&caller_name=" + android.net.Uri.encode(callerName) +
                "&caller_photo=" + android.net.Uri.encode(callerPhoto) +
                "&call_screen=1"
        web.loadUrl(url)

        // POINT 3: dering mulai di sini juga (kalau FCM belum memulainya).
        if (intent?.action == ACTION_INCOMING) CallRingService.start(this)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        readIntent(intent)
    }

    private fun readIntent(intent: Intent?) {
        if (intent == null) return
        callId = intent.getStringExtra(CallLaunch.EXTRA_CALL_ID) ?: callId
        callType = intent.getStringExtra(CallLaunch.EXTRA_CALL_TYPE) ?: callType
        callerName = intent.getStringExtra(CallLaunch.EXTRA_CALLER_NAME) ?: callerName
        callerPhoto = intent.getStringExtra(CallLaunch.EXTRA_CALLER_PHOTO) ?: callerPhoto

        when (intent.action) {
            ACTION_ACCEPT -> {
                // POINT 3: dering mati seketika saat Terima.
                CallRingService.stop(this)
                CallNotifier.cancel(this)
                web.postDelayed({
                    web.evaluateJavascript(
                        "window.__slcAcceptCallById && window.__slcAcceptCallById('$callId');", null
                    )
                }, 700)
            }
            ACTION_DECLINE -> {
                // POINT 3: Tolak -> dering mati + hapus sinyal panggilan.
                CallRingService.stop(this)
                CallNotifier.cancel(this)
                web.postDelayed({
                    web.evaluateJavascript(
                        "window.__slcDeclineCallById && window.__slcDeclineCallById('$callId');", null
                    )
                }, 500)
                finish()
            }
        }
    }

    override fun onDestroy() {
        try { web.destroy() } catch (_: Throwable) { }
        super.onDestroy()
    }

    companion object {
        const val ACTION_INCOMING = "ai.smartools.livechat.CALL_INCOMING"
        const val ACTION_ACCEPT = "ai.smartools.livechat.CALL_ACCEPT"
        const val ACTION_DECLINE = "ai.smartools.livechat.CALL_DECLINE"
    }
}
