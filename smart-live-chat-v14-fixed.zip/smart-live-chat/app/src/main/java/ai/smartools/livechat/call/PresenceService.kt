package ai.smartools.livechat.call

import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.ChildEventListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase

/**
 * PresenceService — cadangan deteksi panggilan masuk.
 *
 * Kalau FCM tidak sampai (push diblokir OEM / app baru dipasang), service
 * ini mendengarkan node `calls` yang masih berstatus "ringing" untuk uid
 * yang login, lalu membuka layar panggilan penuh.
 *
 * POINT 1: service ini memakai sesi Firebase yang SUDAH tersimpan. Kalau
 * belum ada sesi, ia diam saja — tidak pernah memunculkan UI Login.
 * POINT 2: panggilan yang terdeteksi langsung membuka CallActivity penuh.
 */
class PresenceService : Service() {

    private var listener: ChildEventListener? = null
    private var ref: com.google.firebase.database.Query? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        try {
            startForeground(
                NOTIF_ID,
                CallNotifier.serviceNotification(this, "Siap menerima panggilan")
            )
        } catch (_: Throwable) { }
        listen()
    }

    private fun listen() {
        val user = try { FirebaseAuth.getInstance().currentUser } catch (_: Throwable) { null }
        if (user == null) {
            // Belum login: tidak ada yang bisa didengarkan. Tidak memaksa login.
            Log.i(TAG, "belum ada sesi tersimpan; presence menunggu")
            return
        }
        val uid = user.uid
        try {
            val q = FirebaseDatabase.getInstance()
                .getReference("calls")
                .orderByChild("status")
                .equalTo("ringing")
            ref = q
            val l = object : ChildEventListener {
                override fun onChildAdded(snap: DataSnapshot, prev: String?) = handle(snap, uid)
                override fun onChildChanged(snap: DataSnapshot, prev: String?) = handle(snap, uid)
                override fun onChildRemoved(snap: DataSnapshot) { }
                override fun onChildMoved(snap: DataSnapshot, prev: String?) { }
                override fun onCancelled(error: DatabaseError) { }
            }
            listener = l
            q.addChildEventListener(l)
        } catch (_: Throwable) { }
    }

    private fun handle(snap: DataSnapshot, uid: String) {
        try {
            val d = snap.value as? Map<*, *> ?: return
            val target = d["targetUid"] as? String ?: return
            if (target != uid) return
            val callerId = d["callerId"] as? String ?: ""
            if (callerId == uid) return
            val created = (d["createdAtMs"] as? Number)?.toLong() ?: 0L
            if (created > 0 && System.currentTimeMillis() - created > 90_000) return

            val id = snap.key ?: return
            val type = d["type"] as? String ?: "voice"
            val name = d["callerName"] as? String ?: "Seseorang"
            val photo = d["callerPhoto"] as? String ?: ""

            // POINT 2: layar panggilan penuh, bukan hanya notifikasi.
            CallNotifier.showIncoming(this, id, type, name, photo)
            CallRingService.start(this)
            CallLaunch.launchDirect(this, id, type, name, photo)
        } catch (_: Throwable) { }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        try { listener?.let { ref?.removeEventListener(it) } } catch (_: Throwable) { }
        super.onDestroy()
    }

    companion object {
        private const val TAG = "SlcPresence"
        private const val NOTIF_ID = 7302

        fun start(ctx: Context) {
            try {
                val i = Intent(ctx, PresenceService::class.java)
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O)
                    ctx.startForegroundService(i) else ctx.startService(i)
            } catch (_: Throwable) { }
        }
    }
}
