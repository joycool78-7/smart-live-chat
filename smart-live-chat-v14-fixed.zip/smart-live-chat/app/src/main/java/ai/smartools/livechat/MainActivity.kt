package ai.smartools.livechat

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import ai.smartools.livechat.call.CallLaunch
import ai.smartools.livechat.call.PresenceService

/**
 * MainActivity — host WebView untuk UI chat.
 *
 * POINT 1: activity ini TIDAK PERNAH menampilkan layar Login Google sendiri.
 * Sesi Firebase dipulihkan dari cache oleh SDK; WebView memakai sesi itu.
 * Login hanya muncul kalau memang belum pernah login / sudah logout manual
 * (diputuskan di sisi web, bukan di sini).
 */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var bridge: NativeBridge

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        web = findViewById(R.id.web)
        bridge = NativeBridge(this, web)
        bridge.attach()

        web.loadUrl("file:///android_asset/www/index.html")

        requestRuntimePermissions()
        startPresence()
        handleCallIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleCallIntent(intent)
    }

    /**
     * POINT 2: kalau aplikasi dibuka dari notifikasi / full-screen intent
     * panggilan, teruskan call_id ke web supaya layar panggilan langsung
     * tampil penuh — tanpa perlu klik notifikasi lagi.
     */
    private fun handleCallIntent(intent: Intent?) {
        val callId = intent?.getStringExtra(CallLaunch.EXTRA_CALL_ID) ?: return
        val accept = intent.getBooleanExtra(CallLaunch.EXTRA_AUTO_ACCEPT, false)
        val js = if (accept)
            "window.__slcAcceptCallById && window.__slcAcceptCallById('$callId');"
        else
            "window.__slcIncomingCall && window.__slcIncomingCall(JSON.stringify({id:'$callId',fullScreen:true}));"
        web.postDelayed({ web.evaluateJavascript(js, null) }, 900)
    }

    private fun startPresence() {
        try {
            val i = Intent(this, PresenceService::class.java)
            ContextCompat.startForegroundService(this, i)
        } catch (_: Throwable) { }
    }

    private fun requestRuntimePermissions() {
        val need = mutableListOf<String>()
        fun add(p: String) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) need.add(p)
        }
        add(Manifest.permission.RECORD_AUDIO)
        add(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, need.toTypedArray(), REQ_PERMS)
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == REQ_PERMS) {
            web.evaluateJavascript("window.__slcPermissionsGranted && window.__slcPermissionsGranted();", null)
        }
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        try { web.destroy() } catch (_: Throwable) { }
        super.onDestroy()
    }

    companion object { const val REQ_PERMS = 4101 }
}
