package ai.smartools.livechat.call

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import ai.smartools.livechat.MainActivity
import ai.smartools.livechat.R
import ai.smartools.livechat.SlcApp

/**
 * CallNotifier — notifikasi panggilan masuk.
 *
 * POINT 2: notifikasi ini SELALU membawa full-screen intent, jadi layar
 * panggilan penuh langsung terbuka (termasuk saat HP terkunci / app
 * tertutup). Notifikasi hanya cadangan; layarnya yang utama.
 */
object CallNotifier {

    const val NOTIF_ID = 7301

    fun showIncoming(
        ctx: Context,
        callId: String,
        type: String?,
        callerName: String?,
        callerPhoto: String?
    ) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return

        val full = CallLaunch.fullScreenPendingIntent(ctx, callId, type, callerName, callerPhoto)
        val accept = CallLaunch.acceptPendingIntent(ctx, callId)
        val decline = CallLaunch.declinePendingIntent(ctx, callId)

        val isVideo = type == "video"
        val title = callerName?.takeIf { it.isNotBlank() } ?: "Seseorang"
        val body = if (isVideo) "Panggilan video Smart Live Chat" else "Panggilan suara Smart Live Chat"

        val b = NotificationCompat.Builder(ctx, SlcApp.CHANNEL_CALLS)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(body)
            .setSubText("Smart Live Chat • LIVE")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setAutoCancel(false)
            .setContentIntent(full)
            .setFullScreenIntent(full, true)   // <-- POINT 2
            .addAction(0, "Tolak", decline)
            .addAction(0, "Terima", accept)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            b.setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
        }

        try { nm.notify(NOTIF_ID, b.build()) } catch (_: Throwable) { }
    }

    fun cancel(ctx: Context) {
        try {
            ctx.getSystemService(NotificationManager::class.java)?.cancel(NOTIF_ID)
        } catch (_: Throwable) { }
    }

    /** Notifikasi foreground service (dipakai CallRingService). */
    fun serviceNotification(ctx: Context, text: String): Notification {
        val open = PendingIntent.getActivity(
            ctx, 0,
            Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(ctx, SlcApp.CHANNEL_SERVICE)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Smart Live Chat")
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setContentIntent(open)
            .build()
    }
}
