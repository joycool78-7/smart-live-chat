package ai.smartools.livechat

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Toast
import ai.smartools.livechat.call.CallLaunch
import ai.smartools.livechat.call.CallNotifier
import ai.smartools.livechat.call.CallRingService
import ai.smartools.livechat.call.FcmService
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.messaging.FirebaseMessaging
import org.json.JSONObject

/**
 * NativeBridge — jembatan JS <-> native (window.AndroidBridge).
 *
 * POINT 1: googleSignIn / googleSignOut hanya dipakai saat user MEMANG
 * memilih login / logout. Tidak ada pemanggilan otomatis yang memunculkan
 * UI Login Google saat aplikasi dibuka atau saat ada panggilan masuk.
 *
 * POINT 2: postMessage({type:'call'}) membuka layar panggilan penuh.
 * POINT 3: notifyCallAnswered mematikan dering di perangkat ini dan
 * mengirim sinyal "answered" supaya perangkat penelepon juga berhenti.
 */
class NativeBridge(private val activity: Activity, private val web: WebView) {

    fun attach() {
        web.addJavascriptInterface(this, "AndroidBridge")
        web.evaluateJavascript("window.__SLC_NATIVE__ = true;", null)
    }

    // ---------------- pesan dari web ----------------
    @JavascriptInterface
    fun postMessage(json: String) {
        try {
            val o = JSONObject(json)
            when (o.optString("type")) {
                "call" -> {
                    val p = JSONObject(o.optString("payload", "{}"))
                    val id = p.optString("id")
                    if (id.isBlank()) return
                    val type = p.optString("type", "voice")
                    val name = p.optString("callerName", "Seseorang")
                    val photo = p.optString("callerPhoto", "")

                    // POINT 2: notifikasi + full-screen intent + layar penuh.
                    CallNotifier.showIncoming(activity, id, type, name, photo)
                    CallRingService.start(activity)
                    CallLaunch.launchDirect(activity, id, type, name, photo)
                }
                "endcall" -> {
                    // POINT 3: panggilan selesai / ditolak -> dering mati.
                    CallRingService.stop(activity)
                    CallNotifier.cancel(activity)
                }
                "notify" -> {
                    val text = o.optString("text")
                    if (text.isNotBlank()) toast(text)
                }
                "badge" -> { /* badge opsional, tidak dipakai di v14 */ }
                "identity" -> { /* identitas dikirim web, tidak perlu aksi */ }
            }
        } catch (_: Throwable) { }
    }

    // ---------------- POINT 3: panggilan diangkat ----------------
    @JavascriptInterface
    fun notifyCallAnswered() {
        // Dering di perangkat ini mati seketika.
        CallRingService.stop(activity)
        CallNotifier.cancel(activity)
    }

    // ---------------- POINT 1: auth ----------------
    @JavascriptInterface
    fun googleSignIn() {
        // Hanya dipanggil saat user menekan tombol Login Google.
        activity.runOnUiThread {
            try {
                val i = Intent(activity, MainActivity::class.java)
                i.putExtra("slc_google_signin", true)
                activity.startActivity(i)
            } catch (_: Throwable) { }
        }
    }

    @JavascriptInterface
    fun googleSignOut() {
        try { FirebaseAuth.getInstance().signOut() } catch (_: Throwable) { }
    }

    // ---------------- FCM ----------------
    @JavascriptInterface
    fun getFcmToken() {
        FirebaseMessaging.getInstance().token.addOnCompleteListener { t ->
            if (t.isSuccessful) {
                val tok = t.result ?: ""
                activity.runOnUiThread {
                    web.evaluateJavascript("window.__slcFcmToken && window.__slcFcmToken('$tok');", null)
                }
            }
        }
    }

    @JavascriptInterface
    fun getSavedFcmToken(): String =
        activity.getSharedPreferences(FcmService.PREFS, Context.MODE_PRIVATE)
            .getString(FcmService.KEY_TOKEN, "") ?: ""

    @JavascriptInterface
    fun refreshFcmToken() { getFcmToken() }

    @JavascriptInterface
    fun ackFcmToken(uid: String) { /* token sudah disimpan web ke RTDB */ }

    @JavascriptInterface
    fun fcmDiagnostics(): String {
        val tok = getSavedFcmToken()
        return JSONObject()
            .put("token", tok)
            .put("pending", false)
            .put("fsi", CallLaunch.canUseFullScreenIntent(activity))
            .toString()
    }

    @JavascriptInterface
    fun sendFcm(serviceAccountJson: String, token: String, dataJson: String, id: String) {
        // Pengiriman FCM dilakukan di sisi web (jalur legacy) atau server.
        // Di sini cukup laporkan gagal supaya web memakai jalur cadangan.
        activity.runOnUiThread {
            web.evaluateJavascript(
                "window.__slcFcmResult && window.__slcFcmResult('$id', false, 'native-sender-disabled');",
                null
            )
        }
    }

    // ---------------- izin & setelan ----------------
    @JavascriptInterface
    fun requestPermissions() {
        activity.runOnUiThread {
            (activity as? MainActivity)?.let { it.recreate() }
        }
    }

    @JavascriptInterface
    fun canUseFullScreenIntent(): Boolean = CallLaunch.canUseFullScreenIntent(activity)

    @JavascriptInterface
    fun openFullScreenIntentSettings() {
        activity.runOnUiThread { CallLaunch.openFullScreenIntentSettings(activity) }
    }

    @JavascriptInterface
    fun requestBatteryExemption() {
        activity.runOnUiThread {
            try {
                val pm = activity.getSystemService(Context.POWER_SERVICE) as PowerManager
                if (!pm.isIgnoringBatteryOptimizations(activity.packageName)) {
                    val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                        .setData(Uri.parse("package:" + activity.packageName))
                    activity.startActivity(i)
                }
            } catch (_: Throwable) { }
        }
    }

    // ---------------- diagnostik ----------------
    @JavascriptInterface
    fun callLog(): String = "Smart Live Chat v14 — log native tidak diaktifkan"

    @JavascriptInterface
    fun clearCallLog() { }

    @JavascriptInterface
    fun setBadge(n: Int) { }

    @JavascriptInterface
    fun testCallScreen() {
        activity.runOnUiThread {
            CallLaunch.launchDirect(activity, "test-call", "voice", "Tes Panggilan", "")
        }
    }

    @JavascriptInterface
    fun downloadApk(url: String) {
        activity.runOnUiThread {
            try {
                activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            } catch (_: Throwable) { }
        }
    }

    private fun toast(msg: String) {
        activity.runOnUiThread { Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show() }
    }
}
