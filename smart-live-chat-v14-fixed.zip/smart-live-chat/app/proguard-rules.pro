# Smart Live Chat — ProGuard rules
-keepclassmembers class ai.smartools.livechat.NativeBridge {
    public *;
}
-keep class ai.smartools.livechat.** { *; }
-dontwarn okhttp3.**
