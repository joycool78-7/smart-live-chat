# Smart Live Chat v14 — Catatan Perubahan

Hanya 4 poin yang diminta yang diubah. Bagian lain (chat, grup, tema, riwayat panggilan,
profil, dsb.) tidak disentuh.

---

## 1. Login Google tidak muncul saat ada panggilan masuk

**Masalah lama:** setiap aplikasi dibuka / setiap panggilan masuk, layar Login Google
sempat tampil karena UI login dirender sebelum sesi Firebase selesai dipulihkan.

**Perbaikan:**
- `www/index.html` — ditambah layar netral `#auth-splash` (logo + spinner). Form login
  sekarang **default tersembunyi** (`class="login-screen hide"`).
- `www/app.js` — `auth.onAuthStateChanged` menyembunyikan splash lebih dulu, lalu:
  - ada sesi tersimpan → langsung masuk aplikasi, layar login tetap tersembunyi;
  - tidak ada sesi → baru layar login dibuka.
- `SlcApp.kt` — `FirebaseAuth.setPersistenceEnabled(true)` + cache offline Realtime
  Database, jadi sesi dipulihkan tanpa UI.
- `MainActivity.kt` — tidak pernah memanggil `googleSignIn()` sendiri.
- `NativeBridge.googleSignIn()` hanya jalan kalau user menekan tombol Login Google.
- `PresenceService` memakai sesi tersimpan; kalau belum ada sesi ia diam (tidak memaksa login).

**Hasil:** login Google hanya muncul kalau user benar-benar belum pernah login atau
sudah Logout manual.

---

## 2. Panggilan masuk langsung tampil layar penuh

**Perbaikan:**
- `AndroidManifest.xml` — `CallActivity` diberi `showWhenLocked="true"`,
  `turnScreenOn="true"`, `showOnLockScreen="true"`, `launchMode="singleTask"`,
  `excludeFromRecents="true"`, plus izin `USE_FULL_SCREEN_INTENT`,
  `SYSTEM_ALERT_WINDOW`, `TURN_SCREEN_ON`, `DISABLE_KEYGUARD`.
- `CallNotifier.kt` — notifikasi panggilan memakai `setFullScreenIntent(pendingIntent, true)`,
  `CATEGORY_CALL`, `PRIORITY_MAX`, `VISIBILITY_PUBLIC`, dan dua aksi **Terima / Tolak**
  langsung di notifikasi.
- `CallLaunch.kt` — satu tempat membuat intent + PendingIntent (immutable) untuk
  full-screen intent, Terima, dan Tolak; ada `launchDirect()` sebagai fallback OEM.
- `FcmService.kt` — saat data-message panggilan masuk: tampilkan notifikasi **dan**
  langsung `CallLaunch.launchDirect(...)`.
- `PresenceService.kt` — cadangan: mendengarkan `calls` berstatus `ringing` untuk uid
  yang login, lalu membuka layar panggilan penuh.
- `CallActivity.kt` — `setShowWhenLocked(true)` + `setTurnScreenOn(true)` +
  `requestDismissKeyguard()`, memuat `index.html?call_screen=1&room_id=...`.
- `www/app.js` — `showIncoming()` mengirim `fullScreen:true`; `readCallParams()`
  sekarang mengenali `call_screen=1` dan **menampilkan layar panggilan masuk**
  (bukan auto-accept), jadi tombol Terima/Tolak langsung bisa diklik.

**Hasil:** layar panggilan penuh muncul sendiri, termasuk saat aplikasi tertutup atau
HP terkunci — tanpa harus klik notifikasi dulu.

---

## 3. Suara "tut..." mati begitu panggilan diangkat

**Perbaikan:**
- `CallRingService.kt` (baru) — dering + getar diputar lewat `USAGE_NOTIFICATION_RINGTONE`
  (STREAM_RING, bukan STREAM_MUSIC) supaya tidak bercampur dengan suara obrolan.
  Aksi `ACTION_STOP` menghentikan MediaPlayer + vibrator seketika.
- `www/app.js`:
  - `joinCall()` memanggil `stopRing()` + `notifyCallAnswered()` **sebelum** menyambung media;
  - `watchCallDoc()` — saat status berubah jadi `accepted`, penelepon juga memanggil
    `stopRing()` + `notifyCallAnswered()` (dering berhenti di kedua perangkat);
  - `__slcDeclineCall` / `__slcDeclineCallById` memanggil `stopRing()` lalu
    `db.ref('calls/'+id).remove()` — sinyal panggilan dihapus, tidak nyangkut;
  - `hideIncoming()` tetap mengirim `{type:'endcall'}` ke native.
- `NativeBridge.notifyCallAnswered()` → `CallRingService.stop()` + `CallNotifier.cancel()`.
- `FcmService` — `call_cancel` / `call_end` → dering mati + `removeCallSignal()`
  (hapus node kalau masih `ringing`, kalau tidak set `status=ended`).
- `CallActivity` — aksi `ACTION_ACCEPT` / `ACTION_DECLINE` mematikan dering lebih dulu.

**Hasil:** tidak ada lagi suara tut... bercampur obrolan; panggilan yang ditolak /
tidak diangkat dibersihkan dari database.

---

## 4. Layar panggilan khas Smart Live Chat

**Perbaikan (semua di `www/index.html` + `www/app.css`):**
- Background gelap elegan dengan gradient **ungu → biru → cyan** + glow live
  (`radial-gradient` berlapis, override `!important` agar menang dari tema lama).
- Header brand: logo kecil "S" gradien + teks **Smart Live Chat** + badge **LIVE**
  merah berkedip (`@keyframes slcLiveBlink` / `slcLivePulse`).
- Foto profil besar bulat di tengah dengan **ring animasi berdenyut** cyan/ungu
  (`pulse-ring`, `vc-ring` conic-gradient, `vc-aura`).
- Nama penerima besar & tebal (26px/900), status **"Smart Live Chat • Memanggil..."**
  dan **"Smart Live Chat • Menghubungkan..."**.
- **Audio wave** animasi di bawah foto (`.vc-wave`, gradien cyan→ungu).
- Tombol **Terima** hijau neon + ikon telepon, **Tolak** merah + ikon telepon terbalik,
  keduanya besar dengan glow.
- Video call: video lawan bicara full screen (`#call-remote`), video sendiri kecil di
  pojok kanan bawah dengan bingkai rounded + border neon cyan (`#call-local`).

Diverifikasi dengan render headless 412×915: gradient ungu-biru-cyan, avatar biru-ungu,
teks putih, tombol hijau & merah neon tampil sesuai rancangan.

---

## Struktur hasil

```
smart-live-chat-fixed/
├── CATATAN-PERUBAHAN.md      <- file ini
├── BUILD-GUIDE.md            <- cara build APK
├── www/                      <- UI web (juga disalin ke assets/www)
└── smart-live-chat/          <- project Android Studio siap build
    ├── settings.gradle, build.gradle, gradle.properties
    └── app/
        ├── build.gradle, google-services.json, proguard-rules.pro
        └── src/main/
            ├── AndroidManifest.xml
            ├── assets/www/           (UI yang sudah diperbaiki)
            ├── java/ai/smartools/livechat/
            │   ├── SlcApp.kt, MainActivity.kt, NativeBridge.kt
            │   └── call/ CallActivity, CallLaunch, CallNotifier,
            │             CallRingService, FcmService, PresenceService
            └── res/ layout, values, mipmap
```

## Catatan penting

- `google-services.json` diisi dari konfigurasi Firebase yang sudah ada di aplikasi
  (`my-chat-86ac6`, package `ai.smartools.livechat`). Kalau project Firebase Anda
  berbeda, ganti file ini dengan milik Anda.
- Kode **belum dikompilasi** di sini (sandbox tidak punya Android SDK). Lihat
  `BUILD-GUIDE.md` untuk build APK di Android Studio.
- Di Android 14+, izin "full-screen intent" bisa dibatasi OEM. Aplikasi menyediakan
  `openFullScreenIntentSettings()` dan `canUseFullScreenIntent()` untuk membuka
  setelannya; aktifkan sekali agar layar panggilan selalu muncul di lockscreen.
